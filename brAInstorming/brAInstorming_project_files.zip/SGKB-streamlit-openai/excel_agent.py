from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv
from langchain_experimental.agents import create_pandas_dataframe_agent
from langchain_openai import ChatOpenAI


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Ask questions about the contents of an Excel workbook via OpenAI."
    )
    parser.add_argument(
        "excel_path",
        type=Path,
        help="Path to the Excel file (e.g. reports.xlsx).",
    )
    parser.add_argument(
        "question",
        nargs="+",
        help="Question to ask about the Excel data.",
    )
    parser.add_argument(
        "--sheet",
        default=None,
        help="Optional sheet name to load. Defaults to the first worksheet.",
    )
    return parser.parse_args()


def load_dataframe(path: Path, sheet: str | None) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Excel file not found: {path}")

    if sheet:
        return pd.read_excel(path, sheet_name=sheet)

    # Load first sheet when no explicit name is provided
    return pd.read_excel(path)


def main() -> None:
    load_dotenv()  # pulls OPENAI_API_KEY from .env if present

    args = parse_args()
    question = " ".join(args.question)
    dataframe = load_dataframe(args.excel_path, args.sheet)

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    agent = create_pandas_dataframe_agent(
        llm,
        dataframe,
        verbose=True,
        allow_dangerous_code=True,
    )

    result = agent.invoke(question)
    print(result["output"])


if __name__ == "__main__":
    main()
