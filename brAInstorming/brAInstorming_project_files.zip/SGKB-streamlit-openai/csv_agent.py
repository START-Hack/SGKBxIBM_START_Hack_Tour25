from __future__ import annotations
import os
from dotenv import load_dotenv

from langchain_openai import ChatOpenAI
from langchain_experimental.agents import create_csv_agent

# 1) Load env (optional if you exported OPENAI_API_KEY already)
load_dotenv()

CSV_PATH = "sales.csv"

def main():
    # 2) Choose an OpenAI chat model
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    # 3) Create agent that can read & compute on the CSV with pandas + Python
    agent = create_csv_agent(
        llm,
        CSV_PATH,
        verbose=True,
        allow_dangerous_code=True  # lets the agent execute safe pandas/python for calculations
    )

    # 4) Ask questions / do calculations
    questions = [
        "Compute total revenue (units * unit_price).",
    ]

    for q in questions:
        print("\nQ:", q)
        result = agent.invoke(q)  # returns {"input": q, "output": "..."}
        print("A:", result["output"])

if __name__ == "__main__":
    main()