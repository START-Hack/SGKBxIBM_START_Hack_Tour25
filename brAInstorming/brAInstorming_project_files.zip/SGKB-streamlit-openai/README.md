# SGKB Streamlit Demo

Dieses Projekt wurde von einer Django-Anwendung in eine Streamlit-App umgebaut. Die Oberfläche bildet das SGKB Finanz-Dashboard nach, inklusive Login, Kennzahlen, Charts, Aufgabenliste und der Einbindung des IBM watsonx Orchestrate Widgets.

## Voraussetzungen
- Python 3.10 oder neuer
- Virtuelle Umgebung (empfohlen)

## Installation
1. Virtuelle Umgebung erstellen und aktivieren:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   ```
2. Abhängigkeiten installieren:
   ```bash
   pip install -r requirements.txt
   ```
3. Optional: `.env` anhand der Vorlage pflegen, damit die IBM watsonx Orchestrate Einbindung aktiv ist.

## Starten
```bash
streamlit run app.py
```

## Funktionsumfang
- Login über Vertragsnummer und PIN (Beispieldaten sind in `app.py` hinterlegt)
- Kontoerstellung direkt in der App
- Dashboard mit Einnahmen, Ausgaben und Zeitraum
- Diagramme für Kategorien, Mobilität und Trend (Plotly)
- Aufgabenliste mit Möglichkeit zum Ergänzen und Abhaken
- Liste der letzten Transaktionen
- Einbettung des IBM watsonx Orchestrate Chatwidgets über `.env`

## Weiterentwicklung
- Die Nutzerdaten können aus einem Backend oder einer Datenbank geladen werden
- Transaktionen lassen sich über APIs oder CSV-Dateien ersetzen
- Styles können in eine separate CSS-Datei ausgelagert werden, um die Anpassung zu erleichtern
