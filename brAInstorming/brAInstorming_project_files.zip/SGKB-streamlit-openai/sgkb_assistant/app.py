from __future__ import annotations

import streamlit as st

from sgkb_assistant.config import configure_page
from sgkb_assistant.pages import render_dashboard, render_login, render_transactions_page
from sgkb_assistant.styles.theme import inject_css
from sgkb_assistant.utils.state import ensure_session_state


def main() -> None:
    configure_page()
    ensure_session_state()
    inject_css()

    if st.session_state["authenticated"] and st.session_state.get("user"):
        active_view = st.session_state.get("active_view", "dashboard")
        if active_view == "transactions":
            render_transactions_page(st.session_state["user"])
        else:
            render_dashboard(st.session_state["user"])
    else:
        render_login()


if __name__ == "__main__":
    main()
