from __future__ import annotations

import base64
import html
from pathlib import Path

import streamlit as st

from sgkb_assistant.components.chatbot import (
    CHATBOT_AVATAR_DATA_URL,
    CHATBOT_MODAL_KEY,
    render_dashboard_chatbot,
)
from sgkb_assistant.components.cards import render_summary_cards
from sgkb_assistant.components.charts import render_category_chart, render_trend_chart
from sgkb_assistant.components.lists import render_transactions
# from sgkb_assistant.components.todo import render_todo_board
from sgkb_assistant.services.data import (
    aggregate_by_category,
    compute_positive_month_streak,
    compute_summary,
    load_transactions,
    load_trend,
)

from sgkb_assistant.utils.persistence import clear_login_state


def _load_logo_base64() -> str:
    logo_path = Path(__file__).resolve().parents[2] / "logo.png"
    try:
        return base64.b64encode(logo_path.read_bytes()).decode("utf-8")
    except FileNotFoundError:
        return ""


LOGO_BASE64 = _load_logo_base64()


def render_dashboard(user: dict[str, object]) -> None:
    df_transactions = load_transactions()
    summary = compute_summary(df_transactions)
    streak_score = compute_positive_month_streak(df_transactions)
    user_name = html.escape(user.get("display_name", ""))
    points_raw = user.get("sgkb_points", 0)
    try:
        points_value = int(points_raw)
    except (TypeError, ValueError):
        points_value = 0
    points_formatted = f"{points_value:,}".replace(",", "'")

    st.markdown(
        f"""
        <style>
        .top-nav__content {{
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
            align-items: stretch;
        }}
        .user-info-card {{
            display: flex;
            flex-direction: column;
            gap: 8px;
            padding: 18px 22px;
            border-radius: 18px;
            background: var(--card);
            border: 1px solid var(--border);
            box-shadow: 0 10px 24px rgba(0, 60, 40, 0.08);
            min-width: 180px;
        }}
        .user-info-card__label {{
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--muted);
        }}
        .user-info-card__title {{
            margin: 0;
            font-size: 20px;
            font-weight: 700;
            color: var(--brand-dark);
        }}
        .user-info-card__hint {{
            margin: 0;
            font-size: 13px;
            color: var(--muted);
        }}
        .user-info-card__metric {{
            display: flex;
            justify-content: space-between;
            align-items: baseline;
            background: var(--brand-soft);
            border: 1px solid var(--brand-outline);
            border-radius: 12px;
            padding: 10px 14px;
            color: var(--brand-dark);
            font-weight: 600;
        }}
        .user-info-card__metric span {{
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: var(--muted);
        }}
        .user-info-card__metric strong {{
            font-size: 22px;
        }}
        .user-info-card--streak {{
            background: var(--positive-soft);
            border-color: var(--brand);
        }}
        .user-info-card--streak .user-info-card__title {{
            color: var(--positive);
        }}
        .user-info-card--streak .user-info-card__hint {{
            color: var(--brand-dark);
            font-size: 12px;
        }}
        @media (max-width: 600px) {{
            .user-info-card {{
                width: 100%;
            }}
        }}
        </style>
        <div class="top-nav">
          <div class="top-nav__content">
            <div class="user-info-card">
              <span class="user-info-card__label">Willkommen zurück</span>
              <h3 class="user-info-card__title">{user_name}</h3>
              <p class="user-info-card__hint">SGKB Finanzassistent</p>
              <div class="user-info-card__metric">
                <span>SGKB Points</span>
                <strong>{points_formatted}</strong>
              </div>
            </div>
            <div class="user-info-card user-info-card--streak">
              <span class="user-info-card__label">Streak Score</span>
              <h3 class="user-info-card__title">3 Monate</h3>
              <p class="user-info-card__hint">mit positiver Einnahmen-Bilanz</p>
            </div>
          </div>
          <div class="top-nav__logo">
            {'<img src="data:image/png;base64,' + LOGO_BASE64 + '" alt="SGKB Logo" />' if LOGO_BASE64 else ''}
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    render_summary_cards(summary)

    col_left, col_right = st.columns([2, 1])
    with col_left:
        st.markdown("<h3>Ausgaben nach Kategorie</h3>", unsafe_allow_html=True)
        st.caption("Aufteilung der letzten Transaktionen")
        render_category_chart(aggregate_by_category(df_transactions))

        st.markdown("<h3>Monatlicher Verlauf</h3>", unsafe_allow_html=True)
        st.caption("Ausgaben der letzten 6 Monate")
        render_trend_chart(load_trend())

    with col_right:
        st.markdown(
            """
            <style>
            .tip-card {
                border-radius: 18px;
                padding: 20px 24px;
                background: #fffbea;
                border: 1px solid #f7e5b5;
                box-shadow: 0 10px 24px rgba(180, 150, 40, 0.12);
                display: flex;
                flex-direction: column;
                gap: 12px;
                margin-bottom: 24px;
                margin-top: 32px;
            }
            .tip-card h3 {
                margin: 0;
                font-size: 18px;
                color: #7a5d00;
            }
            .tip-card p {
                margin: 0;
                color: #6b5c2e;
                line-height: 1.45;
                font-size: 14px;
            }
            .tip-card .sponsored {
                margin-top: 4px;
                font-size: 12px;
                color: #9f9884;
            }
            .tip-card a {
                color: #0057d9;
                font-weight: 600;
                text-decoration: none;
            }
            .tip-card a:hover {
                text-decoration: underline;
            }
            </style>
            <div class="tip-card">
              <h3>Spartipp</h3>
              <p>Spare bei deinem Mobilabo, indem du zu Sunrise wechselst. <a href="https://www.comparis.ch/telecom" target="_blank" rel="noopener">Hier klicken.</a></p>
              <div class="sponsored">Gesponsert von Comparis</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        button_help_text = "Mika öffnen"
        button_text_css = (
            "color: transparent !important; text-shadow: none !important;"
            if CHATBOT_AVATAR_DATA_URL
            else "color: #ffffff !important;"
        )
        gradient_css = "linear-gradient(90deg, #7b61ff, #1e90ff)"
        hover_gradient_css = "linear-gradient(90deg, #6b4dff, #1373ff)"
        if CHATBOT_AVATAR_DATA_URL:
            background_image_css = f"{gradient_css}, url('{CHATBOT_AVATAR_DATA_URL}')"
            hover_background_image_css = f"{hover_gradient_css}, url('{CHATBOT_AVATAR_DATA_URL}')"
            background_size_css = "100% 100%, 54px 54px"
            background_position_css = "center, center"
            background_repeat_css = "no-repeat, no-repeat"
        else:
            background_image_css = gradient_css
            hover_background_image_css = hover_gradient_css
            background_size_css = "100% 100%"
            background_position_css = "center"
            background_repeat_css = "no-repeat"
        st.markdown(
            f"""
            <style>
            button[title=\"{button_help_text}\"] {{
                width: 100% !important;
                border-radius: 18px !important;
                min-height: 96px !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                background-image: {background_image_css} !important;
                background-size: {background_size_css} !important;
                background-position: {background_position_css} !important;
                background-repeat: {background_repeat_css} !important;
                background-color: transparent !important;
                {button_text_css}
                font-weight: 600 !important;
                letter-spacing: 0.04em !important;
                padding: 14px 18px !important;
                border: none !important;
                box-shadow: 0 14px 30px rgba(123, 97, 255, 0.25) !important;
                transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.3s ease !important;
                position: relative !important;
                overflow: hidden !important;
            }}
            button[title=\"{button_help_text}\"]:hover {{
                background-image: {hover_background_image_css} !important;
                box-shadow: 0 20px 36px rgba(123, 97, 255, 0.35) !important;
                transform: translateY(-2px) !important;
            }}
            button[title=\"{button_help_text}\"]:focus-visible {{
                outline: 3px solid rgba(123, 97, 255, 0.5) !important;
                outline-offset: 2px !important;
            }}
            </style>
            """,
            unsafe_allow_html=True,
        )
        if st.button("Mika", key="dashboard_mika_launcher", help=button_help_text):
            st.session_state[CHATBOT_MODAL_KEY] = True

        render_dashboard_chatbot(current_user=user, show_launcher=False)

        # render_todo_board()

    render_transactions(df_transactions, show_view_all_button=True)

    

    # Sidebar oben
    st.sidebar.title(f"{user['display_name']}")
    if st.sidebar.button("Abmelden"):
        clear_login_state()
        st.session_state.clear()
        st.rerun()


    # --- Platzhalter, damit Button + Link nach unten rutschen ---
    st.sidebar.markdown("<div style='flex-grow:1;'></div>", unsafe_allow_html=True)

    # --- Unten in der Sidebar: Button + Link ---
    st.sidebar.markdown(
        """
        <style>
        /* Container für den fixierten Bereich unten in der Sidebar */
        .sidebar-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 16rem;  /* Standardbreite der Sidebar */
            padding: 16px;
        }
        </style>
        <div class="sidebar-footer">
            <div style="margin-top:10px;">
                <a href="https://www.google.ch" target="_blank"
                   style="color:#5f6a72; font-size:13px; text-decoration:none;">
                    Datenschutz
                </a>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
