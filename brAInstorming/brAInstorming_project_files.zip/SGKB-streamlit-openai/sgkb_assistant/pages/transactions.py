from __future__ import annotations

from calendar import month_name

import pandas as pd
import streamlit as st

from sgkb_assistant.components.lists import render_transaction_list
from sgkb_assistant.services.data import load_transactions

MONTH_LABELS_DE = {
    1: "Januar",
    2: "Februar",
    3: "März",
    4: "April",
    5: "Mai",
    6: "Juni",
    7: "Juli",
    8: "August",
    9: "September",
    10: "Oktober",
    11: "November",
    12: "Dezember",
}


def render_transactions_page(_user: dict[str, str]) -> None:
    st.markdown("### Alle Transaktionen")
    st.caption("Vollständiger Verlauf, gruppiert nach Monat")

    if st.button("Zurück zum Dashboard", key="back_to_dashboard"):
        st.session_state["active_view"] = "dashboard"
        st.session_state["transactions_months_loaded"] = 3
        st.rerun()

    df_transactions = load_transactions().copy()
    if df_transactions.empty:
        st.info("Noch keine Transaktionen vorhanden.")
        return

    if "month" not in df_transactions.columns:
        df_transactions["month"] = df_transactions["date"].dt.to_period("M")

    df_transactions = df_transactions.sort_values(["date", "id"], ascending=[False, False])
    months_loaded = st.session_state.get("transactions_months_loaded", 3)

    grouped: dict[pd.Period, pd.DataFrame] = {
        period: group.copy()
        for period, group in df_transactions.groupby("month")
    }
    if not grouped:
        st.info("Keine Transaktionsdaten gefunden.")
        return

    sorted_periods = sorted(grouped.keys(), reverse=True)
    months_loaded = max(1, min(months_loaded, len(sorted_periods)))

    for period in sorted_periods[:months_loaded]:
        label = _format_period(period)
        st.markdown(f"#### {label}")
        month_df = grouped[period].sort_values("date", ascending=False)
        render_transaction_list(month_df)

    if months_loaded < len(sorted_periods):
        if st.button("Mehr anzeigen", key="load_more_transactions"):
            st.session_state["transactions_months_loaded"] = months_loaded + 3
            st.rerun()
    else:
        st.caption("Alle verfügbaren Monate wurden geladen.")


def _format_period(period: pd.Period) -> str:
    try:
        month_label = MONTH_LABELS_DE.get(period.month, month_name[period.month])
    except AttributeError:  # pragma: no cover - defensive fallback
        return str(period)
    return f"{month_label} {period.year}"
