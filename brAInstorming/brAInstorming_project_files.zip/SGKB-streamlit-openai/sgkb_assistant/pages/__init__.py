from __future__ import annotations

from importlib import import_module

_login = import_module(".1_Login", __name__)
_dashboard = import_module(".2_Dashboard", __name__)
_transactions = import_module(".transactions", __name__)

render_login = _login.render_login
render_dashboard = _dashboard.render_dashboard
render_transactions_page = _transactions.render_transactions_page

__all__ = ["render_login", "render_dashboard", "render_transactions_page"]
