from __future__ import annotations

import streamlit as st

from sgkb_assistant.constants import DEFAULT_TODO_ITEMS
from sgkb_assistant.services.auth import authenticate, register_user
from sgkb_assistant.utils.persistence import save_login_state


def render_login() -> None:
    st.markdown(
        """
        <div class='login-card'>
          <h1>SGKB E-Banking Login</h1>
          <p class='muted'>Sicheres Login für Ihren digitalen Assistenten</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    login_tab, register_tab = st.tabs(["Anmelden", "Konto erstellen"])

    with login_tab:
        with st.form("login_form"):
            contract_number = st.text_input("Vertragsnummer", max_chars=20)
            pin = st.text_input("PIN", type="password", max_chars=12)
            submitted = st.form_submit_button("Anmelden", use_container_width=True)
            if submitted:
                user = authenticate(contract_number, pin)
                if user:
                    st.session_state["authenticated"] = True
                    st.session_state["user"] = user
                    st.session_state["login_error"] = ""
                    st.success(f"Willkommen zurück, {user['display_name']}!")
                    st.session_state["todo_items"] = list(DEFAULT_TODO_ITEMS)
                    save_login_state(True, user)
                    st.rerun()
                else:
                    st.session_state["login_error"] = "Ungültige Vertragsnummer oder PIN."
        if st.session_state.get("login_error"):
            st.error(st.session_state["login_error"])

    with register_tab:
        with st.form("register_form"):
            new_contract = st.text_input("Vertragsnummer", max_chars=20, key="register_contract")
            display_name = st.text_input("Anzeigename", max_chars=80, key="register_display")
            new_pin = st.text_input("PIN", type="password", max_chars=12, key="register_pin")
            new_pin_confirm = st.text_input("PIN bestätigen", type="password", max_chars=12, key="register_pin_confirm")
            submitted_register = st.form_submit_button("Konto erstellen", use_container_width=True)
            if submitted_register:
                if new_pin != new_pin_confirm:
                    st.error("PIN und Bestätigung stimmen nicht überein.")
                else:
                    success, payload = register_user(new_contract, new_pin, display_name)
                    if success:
                        new_user = payload
                        st.session_state["authenticated"] = True
                        st.session_state["user"] = new_user
                        st.session_state["login_error"] = ""
                        st.session_state["todo_items"] = list(DEFAULT_TODO_ITEMS)
                        st.success(f"Konto erstellt. Willkommen, {new_user['display_name']}!")
                        save_login_state(True, new_user)
                        st.rerun()
                    else:
                        st.error(payload)
