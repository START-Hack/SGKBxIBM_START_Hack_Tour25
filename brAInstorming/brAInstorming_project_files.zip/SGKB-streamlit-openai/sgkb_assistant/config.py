from __future__ import annotations

from functools import lru_cache

from dotenv import load_dotenv
import streamlit as st

# Load .env values as soon as the module is imported so downstream modules see them.
load_dotenv()

PAGE_TITLE = "SGKB Finanzassistent"
PAGE_ICON = ":bank:"
PAGE_LAYOUT = "wide"


@lru_cache(maxsize=1)
def configure_page() -> None:
    """Ensure Streamlit page configuration is applied only once."""
    st.set_page_config(page_title=PAGE_TITLE, page_icon=PAGE_ICON, layout=PAGE_LAYOUT)
