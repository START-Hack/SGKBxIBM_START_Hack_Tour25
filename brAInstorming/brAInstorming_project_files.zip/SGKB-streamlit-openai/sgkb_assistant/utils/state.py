from __future__ import annotations

from datetime import date, datetime

import streamlit as st

from sgkb_assistant.constants import DEFAULT_TODO_ITEMS, DEFAULT_USERS
from sgkb_assistant.utils.persistence import load_login_state


def format_currency(value: float) -> str:
    return "CHF {:,.2f}".format(value).replace(",", "'")


def ensure_session_state() -> None:
    users = st.session_state.setdefault("users", list(DEFAULT_USERS))
    st.session_state.setdefault("todo_items", list(DEFAULT_TODO_ITEMS))
    st.session_state.setdefault("login_error", "")
    st.session_state.setdefault("active_view", "dashboard")
    st.session_state.setdefault("transactions_months_loaded", 3)

    stored_auth = load_login_state()
    if stored_auth:
        stored_user = stored_auth.get("user")
        if stored_user and stored_user.get("contract_number"):
            contract = stored_user["contract_number"]
            if not any(user.get("contract_number") == contract for user in users):
                users.append(stored_user)
        st.session_state["authenticated"] = True
        st.session_state["user"] = stored_user
    else:
        st.session_state.setdefault("authenticated", False)
        st.session_state.setdefault("user", None)


def parse_due_date(value: str | date) -> date:
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value).date()
        except ValueError:
            return date.today()
    return date.today()
