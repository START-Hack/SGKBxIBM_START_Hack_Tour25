from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional


_STATE_DIR = Path.home() / ".sgkb_assistant"
_STATE_FILE = _STATE_DIR / "login_state.json"


def load_login_state() -> Optional[Dict[str, Any]]:
    """Return the persisted login state if it exists and looks valid."""
    if not _STATE_FILE.exists():
        return None

    try:
        with _STATE_FILE.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None

    if not isinstance(data, dict):
        return None

    authenticated = bool(data.get("authenticated"))
    user = data.get("user")
    if authenticated and isinstance(user, dict):
        return {"authenticated": True, "user": user}

    return None


def save_login_state(authenticated: bool, user: Optional[Dict[str, Any]]) -> None:
    """Persist the login state to disk."""
    if not authenticated or user is None:
        clear_login_state()
        return

    try:
        _STATE_DIR.mkdir(parents=True, exist_ok=True)
        with _STATE_FILE.open("w", encoding="utf-8") as handle:
            json.dump({"authenticated": bool(authenticated), "user": user}, handle, ensure_ascii=True, indent=2)
    except OSError:
        # Silently ignore persistence issues – session_state will continue to work.
        pass


def clear_login_state() -> None:
    """Remove any persisted login state."""
    try:
        _STATE_FILE.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass
