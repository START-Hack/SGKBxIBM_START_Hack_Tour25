from __future__ import annotations

import streamlit as st

from sgkb_assistant.utils.state import format_currency


def render_summary_cards(summary: dict[str, object]) -> None:
    col1, col2, col3 = st.columns(3)
    with col1:
        with st.container():
            st.markdown("<h4>Einnahmen</h4>", unsafe_allow_html=True)
            st.markdown(
                f"<div class='value'>{format_currency(summary['income'])}</div>",
                unsafe_allow_html=True,
            )
            st.markdown('</div>', unsafe_allow_html=True)
    with col2:
        with st.container():
            st.markdown("<h4>Ausgaben</h4>", unsafe_allow_html=True)
            st.markdown(
                f"<div class='value'>{format_currency(summary['spend'])}</div>",
                unsafe_allow_html=True,
            )
            st.markdown('</div>', unsafe_allow_html=True)
    with col3:
        range_label = "Keine Daten"
        if summary.get("start") and summary.get("end"):
            start = summary["start"].strftime("%d.%m.%Y")
            end = summary["end"].strftime("%d.%m.%Y")
            range_label = f"{start} - {end}"
        with st.container():
            st.markdown("<h4>Zeitraum</h4>", unsafe_allow_html=True)
            st.markdown(
                f"<div class='value'>{range_label}</div>",
                unsafe_allow_html=True,
            )
            st.markdown('</div>', unsafe_allow_html=True)
