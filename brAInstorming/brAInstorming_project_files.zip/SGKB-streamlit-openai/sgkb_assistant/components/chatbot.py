from __future__ import annotations

import base64
import html
import re
from pathlib import Path
from typing import Dict, List, Optional

import streamlit as st

from sgkb_assistant.constants import CHATBOT_AVATAR_PATH
from sgkb_assistant.services.open_ai_connection import (
    OpenAIConnectionError,
    generate_chatbot_response,
)

# -------------------------
# Defaults / Session Keys
# -------------------------
DEFAULT_USERS: List[Dict[str, object]] = [
    {
        "contract_number": "70010001",
        "pin": "1357",
        "display_name": "Max Muster",
        "sgkb_points": 1820,
    },
]

CHATBOT_MODAL_KEY = "show_dashboard_chatbot"
CHATBOT_MESSAGES_KEY = "dashboard_chatbot_messages"
CHATBOT_FORM_KEY = "dashboard_chatbot_form"
CHATBOT_INPUT_KEY = "dashboard_chatbot_input"
CHATBOT_CURRENT_USER_KEY = "dashboard_chatbot_current_user"

DEFAULT_CHATBOT_HISTORY = [
    {
        "role": "assistant",
        "content": "Hallo, ich bin Mika – deine Finanzfreundin. Wie kann ich helfen?",
    },
]

PROMPT_SUGGESTIONS: List[str] = [
    "Wie viel Geld habe ich gestern ausgegeben?",
    "Welche Ausgaben waren diesen Monat am höchsten?",
    "Gib mir Tipps, wie ich mehr sparen kann.",
]

# -------------------------
# Utils
# -------------------------
def _load_avatar_data_url(path: Path) -> str:
    try:
        image_bytes = path.read_bytes()
    except FileNotFoundError:
        return ""
    encoded = base64.b64encode(image_bytes).decode("utf-8")
    return f"data:image/png;base64,{encoded}"


CHATBOT_AVATAR_DATA_URL = _load_avatar_data_url(CHATBOT_AVATAR_PATH)


def _ensure_state(current_user: Optional[Dict[str, object]] = None) -> None:
    st.session_state.setdefault(CHATBOT_MODAL_KEY, False)
    st.session_state.setdefault(CHATBOT_MESSAGES_KEY, list(DEFAULT_CHATBOT_HISTORY))
    if CHATBOT_CURRENT_USER_KEY not in st.session_state:
        st.session_state[CHATBOT_CURRENT_USER_KEY] = current_user or (
            DEFAULT_USERS[0] if DEFAULT_USERS else {"display_name": "User"}
        )


def _get_initials(name: str) -> str:
    if not name:
        return "?"
    parts = [p for p in name.strip().split() if p]
    if len(parts) >= 2:
        return (parts[0][0] + parts[1][0]).upper()
    return parts[0][0].upper()


def _render_user_avatar_html(display_name: str) -> str:
    initials = html.escape(_get_initials(display_name))
    return f"""
    <div class="chat-avatar user" title="{html.escape(display_name)}">
        <span>{initials}</span>
    </div>
    """


# -------------------------
# Sanitizing / Repair
# -------------------------
# Spezifische Wrapper entfernen, falls Nachrichten früher als fertiges HTML gespeichert wurden
_WRAPPER_RE = re.compile(
    r'\s*<div\s+class=["\']?chat-(?:bubble|message)["\']?[^>]*>(?P<inner>.*?)</div>\s*',
    re.IGNORECASE | re.DOTALL,
)
_TAG_RE = re.compile(r"<[^>]+>")


def _strip_all_html(s: str) -> str:
    """Entfernt frühere HTML-Reste aus gespeicherten Nachrichten (History säubern)."""
    if not s:
        return ""
    # 1) Chat-Wrapper entkernen (rekursiv, falls verschachtelt)
    prev = None
    cur = s
    while prev != cur:
        prev = cur
        m = _WRAPPER_RE.fullmatch(cur.strip())
        if m:
            cur = m.group("inner")
    # 2) Übrige Tags raus
    cur = _TAG_RE.sub("", cur)
    # 3) Entities zurückwandeln
    return html.unescape(cur).strip()


def _sanitize_message(raw: str) -> str:
    """Für neue Eingaben: zu Plaintext machen und Zeilenumbrüche in <br/> umwandeln."""
    if not raw:
        return ""
    safe = html.escape(raw).replace("\n", "<br />")
    return safe


# -------------------------
# Styling
# -------------------------
def _inject_styles() -> None:
    st.markdown(
        """
        <style>
        .chatbot-container{display:flex;flex-direction:column;gap:1rem;}

        .chat-message{display:flex;align-items:flex-end;gap:0.75rem;width:100%;}
        .chat-message.chat-assistant{flex-direction:row;justify-content:flex-start;}
        .chat-message.chat-user{flex-direction:row-reverse;justify-content:flex-start;}

        .chat-avatar{width:42px;height:42px;flex:0 0 42px;display:flex;align-items:center;justify-content:center;}
        .chat-avatar img{width:42px;height:42px;border-radius:50%;object-fit:cover;border:2px solid var(--brand,#009639);box-shadow:0 2px 6px rgba(0,0,0,0.08);}
        .chat-avatar.user{border-radius:50%;background:var(--bg,#f3f6f4);color:var(--brand-dark,#007a53);font-weight:700;font-size:0.95rem;border:1px solid var(--border,#cad8cf);box-shadow:0 2px 6px rgba(0,0,0,0.06);}

        .chat-bubble{
          display:inline-flex;flex-direction:column;
          max-width:min(520px,80%);padding:0.75rem 1rem;border-radius:16px;
          line-height:1.5;font-size:0.95rem;word-break:break-word;
          box-shadow:0 1px 4px rgba(15,23,42,0.1);
        }

        .chat-message.chat-assistant .chat-bubble{
          background: var(--positive_soft, rgba(64,155,208,.12));
          border:1px solid var(--border,#cad8cf);
          color:var(--brand-dark,#0b6b50);
        }
        .chat-message.chat-user .chat-bubble{
          background:var(--brand,#009639);
          color:var(--card,#ffffff);
        }

        [data-testid="stForm"] .stTextInput>div>div>input{
          border:2px solid var(--brand,#009639);border-radius:12px;padding:0.75rem 1rem;
        }
        [data-testid="stForm"] .stButton>button{
          background:linear-gradient(90deg,var(--brand-dark,#007a53),var(--brand,#009639));
          color:var(--card,#fff);border:1px solid var(--brand-dark,#007a53);border-radius:999px;
          padding:0.5rem 1.5rem;font-weight:600;
        }

        .chatbot-footer{margin-top:0.5rem;font-size:0.75rem;color:var(--muted_soft,#9ca3af);text-align:center;}

        .chatbot-suggestions{display:flex;flex-wrap:wrap;gap:0.5rem;}
        .chatbot-suggestions button{
          width:auto;max-width:100%;
          border-radius:999px;border:1px solid var(--border,#cad8cf);background:var(--card,#fff);color:var(--brand-dark,#007a53);
          padding:0.4rem 0.75rem;font-size:0.85rem;box-shadow:0 1px 3px rgba(15,23,42,0.08);
        }
        .chatbot-suggestions button:hover{border-color:var(--brand,#009639);color:var(--brand,#009639);}
        </style>
        """,
        unsafe_allow_html=True,
    )


# -------------------------
# Chat Logic
# -------------------------
def _process_user_message(text: str, history: List[Dict[str, str]]) -> None:
    cleaned = (text or "").strip()
    if not cleaned:
        return

    # Nur Plaintext in History speichern
    safe_html = _sanitize_message(cleaned)
    plain_text = re.sub(r"<br\s*/?>", "\n", safe_html)
    plain_text = html.unescape(plain_text)

    # Snapshot ohne aktuelle User-Message an OpenAI geben
    history_snapshot = list(history)
    history.append({"role": "user", "content": plain_text})

    with st.spinner("Assistent antwortet..."):
        try:
            assistant_raw = generate_chatbot_response(
                plain_text,
                history=history_snapshot,
            )
        except OpenAIConnectionError as exc:
            assistant_raw = (
                "Entschuldigung, die Anfrage konnte nicht verarbeitet werden. "
                f"(Details: {exc})"
            )

    # Antwort als Plaintext speichern (keine HTML-Fragmente)
    history.append({"role": "assistant", "content": str(assistant_raw)})
    st.rerun()


@st.dialog("Chatbot", width="medium")
def _render_chatbot_dialog() -> None:
    _inject_styles()

    history = st.session_state[CHATBOT_MESSAGES_KEY]
    current_user = st.session_state[CHATBOT_CURRENT_USER_KEY]
    display_name = current_user.get("display_name", "User")

    # --- History einmalig "ent-HTML-isieren"
    for i, chat in enumerate(history):
        history[i]["content"] = _strip_all_html(str(chat.get("content", "")))

    st.markdown("<div class='chatbot-container'>", unsafe_allow_html=True)

    for chat in history:
        is_user = chat["role"] == "user"

        # Avatar
        if is_user:
            avatar_html = _render_user_avatar_html(display_name)
        else:
            avatar_html = (
                f"<div class='chat-avatar'><img src='{CHATBOT_AVATAR_DATA_URL}' alt='Mika Avatar' /></div>"
                if CHATBOT_AVATAR_DATA_URL
                else "<div class='chat-avatar'></div>"
            )

        # Inhalt sicher rendern - erst HTML entfernen, dann escapen + <br>
        clean_content = _strip_all_html(str(chat.get("content", "")))
        content_html = html.escape(clean_content).replace("\n", "<br />")

        st.markdown(
            f"""
            <div class="chat-message {'chat-user' if is_user else 'chat-assistant'}">
                {avatar_html}
                <div class="chat-bubble">{content_html}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("</div>", unsafe_allow_html=True)

    # Vorschläge
    st.markdown("<div class='chatbot-suggestions'>", unsafe_allow_html=True)
    suggestion_cols = st.columns(len(PROMPT_SUGGESTIONS))
    for idx, suggestion in enumerate(PROMPT_SUGGESTIONS):
        if suggestion_cols[idx].button(
            suggestion,
            key=f"{CHATBOT_FORM_KEY}_suggestion_{idx}",
        ):
            _process_user_message(suggestion, history)
    st.markdown("</div>", unsafe_allow_html=True)

    # Eingabe
    with st.form(CHATBOT_FORM_KEY, clear_on_submit=True):
        user_message = st.text_input("Message", key=CHATBOT_INPUT_KEY, label_visibility="collapsed")
        submitted = st.form_submit_button("Senden")
        if submitted:
            _process_user_message(user_message, history)

    st.markdown("<div class='chatbot-footer'></div>", unsafe_allow_html=True)

    # Optional: Reset-Button, falls Session „klebt“
    if st.button("Chat zurücksetzen", key="reset_dashboard_chatbot"):
        st.session_state[CHATBOT_MESSAGES_KEY] = list(DEFAULT_CHATBOT_HISTORY)
        st.rerun()

    if st.button("Schliessen", key="close_dashboard_chatbot"):
        st.session_state[CHATBOT_MODAL_KEY] = False
        st.rerun()


def render_dashboard_chatbot(
    open_button_label: str = "Mika",
    current_user: Optional[Dict[str, object]] = None,
    show_launcher: bool = True,
) -> None:
    _ensure_state(current_user=current_user)

    if show_launcher:
        button_text_css = (
            "color: transparent !important; text-shadow: none !important;"
            if CHATBOT_AVATAR_DATA_URL
            else "color: #ffffff !important;"
        )

        gradient_css = "linear-gradient(90deg, #7b61ff, #1e90ff)"
        hover_gradient_css = "linear-gradient(90deg, #6b4dff, #1373ff)"

        if CHATBOT_AVATAR_DATA_URL:
            background_image_css = f"{gradient_css}, url('{CHATBOT_AVATAR_DATA_URL}')"
            hover_background_image_css = f"{hover_gradient_css}, url('{CHATBOT_AVATAR_DATA_URL}')"
            background_size_css = "100% 100%, 54px 54px"
            background_position_css = "center, center"
            background_repeat_css = "no-repeat, no-repeat"
        else:
            background_image_css = gradient_css
            hover_background_image_css = hover_gradient_css
            background_size_css = "100% 100%"
            background_position_css = "center"
            background_repeat_css = "no-repeat"

        help_text = "Mika öffnen"

        st.markdown(
            f"""
            <style>
            button[title="{help_text}"] {{
                width: 100% !important;
                border-radius: 18px !important;
                min-height: 96px !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                background-image: {background_image_css} !important;
                background-size: {background_size_css} !important;
                background-position: {background_position_css} !important;
                background-repeat: {background_repeat_css} !important;
                background-color: transparent !important;
                {button_text_css}
                font-weight: 600 !important;
                letter-spacing: 0.04em !important;
                padding: 14px 18px !important;
                border: none !important;
                box-shadow: 0 14px 30px rgba(123, 97, 255, 0.25) !important;
                transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.3s ease !important;
                position: relative !important;
                overflow: hidden !important;
            }}
            button[title="{help_text}"]:hover {{
                background-image: {hover_background_image_css} !important;
                box-shadow: 0 20px 36px rgba(123, 97, 255, 0.35) !important;
                transform: translateY(-2px) !important;
            }}
            button[title="{help_text}"]:focus-visible {{
                outline: 3px solid rgba(123, 97, 255, 0.5) !important;
                outline-offset: 2px !important;
            }}
            </style>
            """,
            unsafe_allow_html=True,
        )

        if st.button(open_button_label, key="open_dashboard_chatbot", help=help_text):
            st.session_state[CHATBOT_MODAL_KEY] = True

    if st.session_state[CHATBOT_MODAL_KEY]:
        _render_chatbot_dialog()