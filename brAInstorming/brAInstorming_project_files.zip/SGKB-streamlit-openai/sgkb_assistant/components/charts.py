from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st

from plotly.colors import hex_to_rgb

from sgkb_assistant.constants import PALETTE
from sgkb_assistant.styles.theme import GLOBAL_COLORS

_PIE_HOVER_CSS_STATE_KEY = "category_pie_hover_css_injected"


def render_category_chart(df: pd.DataFrame) -> None:
    if df.empty:
        st.info("Noch keine Ausgaben vorhanden.")
        return
    chart = px.pie(
        df,
        names="category",
        values="value",
        hole=0.58,
        color_discrete_sequence=PALETTE,
    )
    chart.update_traces(
        textinfo="label+percent",
        textposition="inside",
        hovertemplate="<b>%{label}</b><br>CHF %{value:,.2f}<br>%{percent}<extra></extra>",
    )
    chart.update_layout(
        showlegend=True,
        legend_title_text="Kategorie",
        margin=dict(l=0, r=0, t=0, b=0),
    )
    st.plotly_chart(chart, use_container_width=True, config={"displaylogo": False})

    if not st.session_state.get(_PIE_HOVER_CSS_STATE_KEY):
        st.markdown(
            """
            <style>
            div[data-testid="stPlotlyChart"] .slices path {
                transition: opacity 0.2s ease;
            }
            div[data-testid="stPlotlyChart"] .slices:hover path {
                opacity: 0.25;
            }
            div[data-testid="stPlotlyChart"] .slices .slice:hover path {
                opacity: 1 !important;
            }
            </style>
            """,
            unsafe_allow_html=True,
        )
        st.session_state[_PIE_HOVER_CSS_STATE_KEY] = True


def render_mobility_chart(df: pd.DataFrame) -> None:
    brand_color = GLOBAL_COLORS.get("brand") or next(iter(GLOBAL_COLORS.values()))
    positive_color = GLOBAL_COLORS.get("positive", brand_color)
    base_palette = PALETTE or [brand_color, positive_color]
    colors = (base_palette * 2)[:2]
    chart = px.bar(
        df,
        x="sub",
        y="value",
        color="sub",
        color_discrete_sequence=colors,
        text_auto=".2f",
    )
    chart.update_layout(showlegend=False, margin=dict(l=0, r=0, t=0, b=0))
    chart.update_yaxes(title="CHF")
    st.plotly_chart(chart, use_container_width=True, config={"displaylogo": False})


def render_trend_chart(df: pd.DataFrame) -> None:
    brand_color = GLOBAL_COLORS.get("brand") or next(iter(GLOBAL_COLORS.values()))
    primary_color = PALETTE[0] if PALETTE else brand_color
    chart = px.line(
        df,
        x="month",
        y="value",
        markers=True,
        color_discrete_sequence=[primary_color],
    )
    r, g, b = hex_to_rgb(primary_color)
    fill_color = f"rgba({r}, {g}, {b}, 0.15)"
    chart.update_traces(
        mode="lines+markers",
        line=dict(width=2.5),
        marker=dict(size=10, line=dict(width=0)),
        fill="tozeroy",
        fillcolor=fill_color,
        hovertemplate="Monat %{x}<br>CHF %{y:,.0f}<extra></extra>",
    )
    chart.update_layout(showlegend=False, margin=dict(l=0, r=0, t=0, b=0))
    chart.update_xaxes(showgrid=False)
    chart.update_yaxes(title="CHF", range=[0, None], zeroline=False, showgrid=False)
    st.plotly_chart(chart, use_container_width=True, config={"displaylogo": False})
