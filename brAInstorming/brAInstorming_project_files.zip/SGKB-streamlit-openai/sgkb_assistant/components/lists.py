from __future__ import annotations

import base64
import re
from functools import lru_cache
from pathlib import Path
from textwrap import dedent

import pandas as pd
import streamlit as st

from sgkb_assistant.utils.state import format_currency


LOGO_ROOT = Path(__file__).resolve().parents[2] / "Logos"
_MIME_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml"}
_LOGO_STYLE_INJECTED = "tx_logo_styles_injected"


def render_transactions(df: pd.DataFrame, *, show_view_all_button: bool = False) -> None:
    st.subheader("Letzte Transaktionen")
    st.caption("Aus den letzten Tagen")
    _ensure_logo_styles()
    items = df.sort_values("date", ascending=False).head(10)
    render_transaction_list(items)
    if show_view_all_button:
        st.write("")
        st.write("")
        if st.button("Alle Transaktionen anzeigen", key="view_all_transactions"):
            st.session_state["active_view"] = "transactions"
            st.session_state["transactions_months_loaded"] = 3
            st.rerun()


def render_transaction_list(items: pd.DataFrame) -> None:
    rows = []
    for _, row in items.iterrows():
        amount = float(row["amount"])
        direction = "minus" if amount < 0 else "plus"
        badge = row["category"]
        if isinstance(row.get("sub"), str) and row["sub"]:
            badge = f"{badge} · {row['sub']}"
        logo_tag = _build_logo_tag(row.get("merchant"))
        rows.append(
            dedent(
                f"""
                <div class='tx-row'>
                  <div class='tx-info'>
                    {logo_tag}
                    <div class='tx-details'>
                      <div class='merchant'>{row['merchant']}</div>
                      <div class='meta'>{row['date'].strftime('%d.%m.%Y')} • <span class='badge'>{badge}</span></div>
                    </div>
                  </div>
                  <div class='amount {direction}'>{'-' if amount < 0 else '+'}{format_currency(abs(amount))}</div>
                </div>
                """
            ).strip()
        )
    st.markdown("<div class='tx-list'>" + "".join(rows) + "</div>", unsafe_allow_html=True)


def _ensure_logo_styles() -> None:
    if st.session_state.get(_LOGO_STYLE_INJECTED):
        return
    st.markdown(
        """
        <style>
        .tx-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .tx-details {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .tx-logo {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: var(--card);
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        .tx-logo img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )
    st.session_state[_LOGO_STYLE_INJECTED] = True


def _build_logo_tag(merchant: object) -> str:
    if not isinstance(merchant, str) or not merchant.strip():
        return _logo_img_html(None, "")
    path = _find_best_logo_path(merchant)
    return _logo_img_html(path, merchant)


def _logo_img_html(path: Path | None, merchant: str) -> str:
    if not path:
        path = _fallback_logo_path()
    if not path:
        return ""
    data_uri = _logo_data_uri(path)
    if not data_uri:
        return ""
    alt = merchant if merchant else path.stem
    return f"<div class='tx-logo'><img src='{data_uri}' alt='{alt}' /></div>"


def _fallback_logo_path() -> Path | None:
    for entry in _logo_entries():
        if entry["path"].stem.lower() == "unknown":
            return entry["path"]
    return None


def _find_best_logo_path(merchant: str) -> Path | None:
    merchant_tokens = _tokenize(merchant)
    if not merchant_tokens:
        return None
    best_score = 0
    best_path: Path | None = None
    for entry in _logo_entries():
        score = _score_tokens(merchant_tokens, entry["tokens"])
        if score > best_score:
            best_score = score
            best_path = entry["path"]
    if best_score == 0:
        return None
    return best_path


def _score_tokens(merchant_tokens: list[str], logo_tokens: list[str]) -> int:
    score = 0
    for m_token in merchant_tokens:
        for l_token in logo_tokens:
            if not l_token:
                continue
            if m_token == l_token:
                score += len(l_token) * 2
            elif m_token in l_token or l_token in m_token:
                score += len(l_token)
    return score


def _logo_data_uri(path: Path) -> str | None:
    mime = _MIME_TYPES.get(path.suffix.lower())
    if not mime:
        return None
    payload = _read_logo_bytes(path)
    if payload is None:
        return None
    encoded = base64.b64encode(payload).decode("utf-8")
    return f"data:{mime};base64,{encoded}"


@lru_cache(maxsize=32)
def _read_logo_bytes(path: Path) -> bytes | None:
    try:
        return path.read_bytes()
    except FileNotFoundError:
        return None


@lru_cache(maxsize=1)
def _logo_entries() -> list[dict[str, object]]:
    entries: list[dict[str, object]] = []
    if not LOGO_ROOT.exists():
        return entries
    for path in sorted(LOGO_ROOT.iterdir()):
        if path.suffix.lower() not in _MIME_TYPES:
            continue
        tokens = _tokenize(path.stem)
        entries.append({"path": path, "tokens": tokens})
    return entries


def _tokenize(value: str) -> list[str]:
    return [token for token in re.findall(r"[a-z0-9]+", value.lower()) if token]
