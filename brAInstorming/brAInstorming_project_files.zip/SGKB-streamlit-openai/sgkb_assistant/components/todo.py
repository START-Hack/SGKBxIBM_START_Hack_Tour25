# from __future__ import annotations

# from datetime import date

# import streamlit as st

# from sgkb_assistant.utils.state import parse_due_date


# def render_todo_board() -> None:
#     st.subheader("To-dos")
#     st.caption("Kurzfristige Aufgaben für Ihren Finanzalltag")
#     todo_items = st.session_state.get("todo_items", [])
#     if not todo_items:
#         st.info("Alle Aufgaben erledigt – grossartig!")
#     else:
#         render_rows = []
#         for idx, item in enumerate(todo_items):
#             due = parse_due_date(item.get("due_date"))
#             render_rows.append((idx, item["text"], due))
#         st.markdown("<div class='todo-board'>", unsafe_allow_html=True)
#         for idx, text, due in render_rows:
#             cols = st.columns([0.75, 0.25])
#             with cols[0]:
#                 st.markdown(
#                     f"""
#                     <div class='todo-row'>
#                       <div>
#                         <div class='merchant'>{text}</div>
#                         <div class='due'>Fällig bis {due.strftime('%d.%m.%Y')}</div>
#                       </div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )
#             with cols[1]:
#                 if st.button("Erledigt", key=f"todo_done_{idx}"):
#                     st.session_state["todo_items"].pop(idx)
#                     st.rerun()
#         st.markdown("</div>", unsafe_allow_html=True)
#     with st.form("add_todo"):
#         new_text = st.text_input("Neue Aufgabe", placeholder="z.B. Dauerauftrag anpassen")
#         new_due = st.date_input("Fälligkeitsdatum", value=date.today())
#         submitted = st.form_submit_button("Aufgabe hinzufügen")
#         if submitted:
#             if not new_text.strip():
#                 st.warning("Bitte eine Aufgabe beschreiben.")
#             else:
#                 st.session_state.setdefault("todo_items", [])
#                 st.session_state["todo_items"].append(
#                     {"text": new_text.strip(), "due_date": new_due.isoformat()}
#                 )
#                 st.success("Aufgabe hinzugefügt.")
#                 st.rerun()
