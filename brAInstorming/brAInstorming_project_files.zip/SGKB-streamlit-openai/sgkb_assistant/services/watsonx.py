from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional, Tuple

import requests
from dotenv import load_dotenv

load_dotenv()

IAM_HOST = os.getenv("IBM_IAM_HOST", "https://iam.cloud.ibm.com")
IAM_TOKEN_URL = f"{IAM_HOST.rstrip('/')}/identity/token"

REGION = os.getenv("IBM_WATSONX_REGION", "eu-de")
BASE_URL = os.getenv("IBM_WATSONX_URL", f"https://{REGION}.ml.cloud.ibm.com")
API_VERSION = os.getenv("IBM_WATSONX_API_VERSION", "2023-05-29")
TEXT_GENERATION_URL = f"{BASE_URL.rstrip('/')}/ml/v1/text/generation?version={API_VERSION}"

MODEL_FALLBACKS = (
    "IBM_WATSONX_MODEL_ID",
    "WATSONX_MODEL_ID",
    "MODEL_ID",
)
DEFAULT_MODEL_ID = next(
    (os.getenv(name) for name in MODEL_FALLBACKS if os.getenv(name)),
    "ibm/granite-13b-instruct-v2",
)

DEFAULT_MAX_NEW_TOKENS = int(os.getenv("IBM_WATSONX_MAX_NEW_TOKENS", "256"))
DEFAULT_TEMPERATURE = float(os.getenv("IBM_WATSONX_TEMPERATURE", "0.2"))
DEFAULT_TOP_P = float(os.getenv("IBM_WATSONX_TOP_P", "1.0"))


class WatsonxError(RuntimeError):
    """Custom exception raised for watsonx integration issues."""


def _first_env(*candidates: str) -> Optional[str]:
    for key in candidates:
        value = os.getenv(key)
        if value:
            return value
    return None


def _resolve_apikey_path() -> Optional[Path]:
    candidates = [Path.cwd() / "apikey.json"]
    module_root = Path(__file__).resolve().parents[2]
    candidates.append(module_root / "apikey.json")

    for path in candidates:
        if path.exists():
            return path
    return None


def load_credentials() -> Tuple[str, Optional[str], Optional[str]]:
    """Return API key plus project_id/space_id from env vars or local apikey.json."""

    api_key = _first_env("IBM_WATSONX_API_KEY", "WATSONX_API_KEY", "GENAI_API_KEY", "API_KEY")
    project_id = _first_env("IBM_WATSONX_PROJECT_ID", "WATSONX_PROJECT_ID", "PROJECT_ID")
    space_id = _first_env("IBM_WATSONX_SPACE_ID", "WATSONX_SPACE_ID", "SPACE_ID")

    if (not api_key) or (not project_id and not space_id):
        json_path = _resolve_apikey_path()
        if json_path and json_path.exists():
            try:
                data = json.loads(json_path.read_text())
            except json.JSONDecodeError as exc:
                raise WatsonxError(f"apikey.json konnte nicht gelesen werden: {exc}") from exc

            api_key = data.get("apikey") or api_key
            project_id = data.get("projectId") or project_id
            space_id = data.get("spaceId") or space_id

    if not api_key:
        raise WatsonxError(
            "IBM watsonx API-Schlüssel nicht gefunden. Setze IBM_WATSONX_API_KEY (oder kompatible Variablen) in der Umgebung "
            "oder ergänze apikey.json mit 'apikey'."
        )

    if not (project_id or space_id):
        raise WatsonxError(
            "Weder project_id noch space_id gefunden. Setze IBM_WATSONX_PROJECT_ID bzw. SPACE_ID in der Umgebung oder in apikey.json."
        )

    return api_key, project_id, space_id


def request_iam_token(api_key: str) -> str:
    payload = {
        "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
        "apikey": api_key,
    }
    headers = {"Content-Type": "application/x-www-form-urlencoded"}

    try:
        response = requests.post(IAM_TOKEN_URL, data=payload, headers=headers, timeout=30)
    except requests.exceptions.RequestException as exc:
        raise WatsonxError(f"IAM Token konnte nicht abgefragt werden ({IAM_TOKEN_URL}): {exc}") from exc

    if response.status_code != 200:
        raise WatsonxError(
            f"IAM Token Anfrage fehlgeschlagen ({response.status_code}). Antwort: {response.text}"
        )

    try:
        return response.json()["access_token"]
    except (KeyError, json.JSONDecodeError) as exc:
        raise WatsonxError(f"IAM Antwort unerwartet: {response.text}") from exc


def build_payload(
    prompt: str,
    project_id: Optional[str],
    space_id: Optional[str],
    model_id: str,
    *,
    max_new_tokens: int = DEFAULT_MAX_NEW_TOKENS,
    temperature: float = DEFAULT_TEMPERATURE,
    top_p: float = DEFAULT_TOP_P,
) -> dict:
    payload: dict[str, object] = {
        "input": prompt,
        "model_id": model_id,
        "parameters": {
            "decoding_method": "sample",
            "max_new_tokens": max_new_tokens,
            "min_new_tokens": 0,
            "stop_sequences": [],
            "repetition_penalty": 1.05,
            "temperature": temperature,
            "top_p": top_p,
        },
    }

    if project_id:
        payload["project_id"] = project_id
    if space_id:
        payload["space_id"] = space_id

    return payload


def generate_text(access_token: str, payload: dict) -> str:
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    try:
        response = requests.post(TEXT_GENERATION_URL, headers=headers, json=payload, timeout=60)
    except requests.exceptions.RequestException as exc:
        raise WatsonxError(f"Textgenerierung fehlgeschlagen ({TEXT_GENERATION_URL}): {exc}") from exc

    if response.status_code != 200:
        raise WatsonxError(
            f"Watsonx Antwort war {response.status_code}. Antworttext: {response.text}"
        )

    body = response.json()
    try:
        return body["results"][0]["generated_text"].strip()
    except (KeyError, IndexError, TypeError) as exc:
        raise WatsonxError(f"Antwort ohne Text erhalten: {body}") from exc


def generate_watsonx_response(prompt: str, *, model_id: Optional[str] = None) -> str:
    api_key, project_id, space_id = load_credentials()
    token = request_iam_token(api_key)
    payload = build_payload(prompt, project_id, space_id, model_id or DEFAULT_MODEL_ID)
    return generate_text(token, payload)

