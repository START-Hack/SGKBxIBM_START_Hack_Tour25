"""Utility helpers for talking to the OpenAI Assistants API."""

from __future__ import annotations

import os
import time
from collections import Counter
from datetime import datetime
from functools import lru_cache
from typing import MutableMapping, Sequence

from dotenv import load_dotenv
from openai import OpenAI

from sgkb_assistant.constants import DEFAULT_TRANSACTIONS

load_dotenv()


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        parsed = int(value)
        return parsed if parsed > 0 else default
    except ValueError:
        return default


DEFAULT_ASSISTANT_ID = os.getenv(
    "OPENAI_ASSISTANT_ID",
    "asst_22QkVzg4LJnbr94aUCZbazb1",
)
DEFAULT_SYSTEM_PROMPT = os.getenv(
    "OPENAI_SYSTEM_PROMPT",
    'Du bist Mika, eine freundliche Finanzassistentin der SGKB. Antworte hilfreich, sachlich und in deutscher Sprache. Weiche nie von Themen die eine Finanzassistentin betreffen ab. Du erhälst Transaktionsdaten der Kund:in. Eine der wichtigsten Spalten ist die "category" Spalte.',
)
DEFAULT_HISTORY_LIMIT = _env_int("OPENAI_HISTORY_LIMIT", 8)
DEFAULT_TRANSACTIONS_PREVIEW = _env_int("OPENAI_TRANSACTIONS_PREVIEW", 5)
DEFAULT_TRANSACTIONS_TOP_CATEGORIES = _env_int("OPENAI_TRANSACTIONS_TOP_CATEGORIES", 6)
DEFAULT_ASSISTANT_POLL_INTERVAL = float(os.getenv("OPENAI_ASSISTANT_POLL_INTERVAL", "0.5"))
DEFAULT_ASSISTANT_MAX_POLLS = _env_int("OPENAI_ASSISTANT_MAX_POLLS", 60)


_client: OpenAI | None = None


class OpenAIConnectionError(RuntimeError):
    """Raised when the OpenAI backend cannot provide a response."""


@lru_cache(maxsize=1)
def _build_transactions_context() -> str:
    data = DEFAULT_TRANSACTIONS
    if not data:
        return "Hinweis: Es stehen keine Demo-Transaktionsdaten zur Verfügung."

    preview_limit = _env_int("OPENAI_TRANSACTIONS_PREVIEW", DEFAULT_TRANSACTIONS_PREVIEW)
    category_limit = _env_int("OPENAI_TRANSACTIONS_TOP_CATEGORIES", DEFAULT_TRANSACTIONS_TOP_CATEGORIES)

    total_rows = len(data)
    categories: Counter[str] = Counter()
    first_date: datetime | None = None
    last_date: datetime | None = None
    sample: list[str] = []

    for entry in data:
        category = str(entry.get("category") or "").strip() or "Unbekannt"
        categories[category] += 1

        date_raw = str(entry.get("date") or "").strip()
        parsed: datetime | None = None
        if date_raw:
            for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y"):
                try:
                    parsed = datetime.strptime(date_raw, fmt)
                    break
                except ValueError:
                    continue
        if parsed:
            if first_date is None or parsed < first_date:
                first_date = parsed
            if last_date is None or parsed > last_date:
                last_date = parsed

        if len(sample) < preview_limit:
            amount_raw = entry.get("amount")
            try:
                amount_text = f"{float(amount_raw):.2f}"
            except (TypeError, ValueError):
                amount_text = str(amount_raw) if amount_raw is not None else "?"
            merchant = str(entry.get("merchant") or "Unbekannte Gegenpartei").strip() or "Unbekannte Gegenpartei"
            currency = str(entry.get("currency") or "CHF").strip() or "CHF"
            trx_id = entry.get("id", "?")
            sample.append(
                f"ID {trx_id} | {date_raw or '?'} | Kategorie: {category} | Betrag: {amount_text} {currency} | Gegenpartei: {merchant}"
            )

    top_categories = ", ".join(
        f"{name} ({count})" for name, count in categories.most_common(category_limit)
    ) or "keine Kategorien verfügbar"

    if first_date and last_date:
        date_span = f"Zeitraum {first_date:%d.%m.%Y} - {last_date:%d.%m.%Y}"
    else:
        date_span = "Zeitraum unbekannt"

    sample_text = "\n    - ".join(sample) if sample else "keine Beispielbuchungen"

    return (
        "Datenreferenz: eingebettete Demo-Transaktionen\n"
        f"- Umfang: {total_rows} Buchungen\n"
        f"- {date_span}\n"
        f"- Häufigste Kategorien: {top_categories}\n"
        "- Beispielbuchungen (verkürzt):\n"
        f"    - {sample_text}\n"
        "- Nutze diese Daten nur als illustrative Referenz, keine echten Kundendaten."
    )


def _sanitize_message(message: MutableMapping[str, str]) -> MutableMapping[str, str]:
    role = (message.get("role") or "").strip().lower()
    content = (message.get("content") or "").strip()
    if role not in {"user", "assistant", "system"}:
        return {}
    if not content:
        return {}
    return {"role": role, "content": content}


def _prepare_history(history: Sequence[MutableMapping[str, str]] | None, limit: int) -> list[dict[str, str]]:
    if not history:
        return []

    trimmed = history[-limit:]
    prepared: list[dict[str, str]] = []
    for entry in trimmed:
        sanitized = _sanitize_message(entry)
        if sanitized:
            prepared.append({"role": sanitized["role"], "content": sanitized["content"]})
    return prepared


def _build_message_payload(text: str) -> list[dict[str, str]]:
    return [{"type": "text", "text": text}]


def _require_client() -> OpenAI:
    global _client

    if _client is not None:
        return _client

    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise OpenAIConnectionError(
            "OPENAI_API_KEY ist nicht gesetzt. Bitte API-Schlüssel in der Umgebung oder .env hinterlegen."
        )

    _client = OpenAI(api_key=api_key)
    return _client


def generate_chatbot_response(
    user_message: str,
    *,
    history: Sequence[MutableMapping[str, str]] | None = None,
    system_prompt: str | None = None,
) -> str:
    """Return a chatbot reply for the current user message."""

    clean_message = (user_message or "").strip()
    if not clean_message:
        raise ValueError("user_message must not be empty")

    assistant_id = (DEFAULT_ASSISTANT_ID or "").strip()
    if not assistant_id:
        raise OpenAIConnectionError(
            "Keine OPENAI_ASSISTANT_ID konfiguriert. Bitte Assistant-ID hinterlegen."
        )

    prompt = (system_prompt if system_prompt is not None else DEFAULT_SYSTEM_PROMPT).strip()
    context = _build_transactions_context()

    if context:
        prompt = f"{prompt}\n\n{context}" if prompt else context

    history_messages = [
        entry
        for entry in _prepare_history(history, DEFAULT_HISTORY_LIMIT)
        if entry.get("role") in {"user", "assistant"}
    ]

    try:
        client = _require_client()
        thread = client.beta.threads.create()

        for entry in history_messages:
            text = (entry.get("content") or "").strip()
            if not text:
                continue
            client.beta.threads.messages.create(
                thread_id=thread.id,
                role=str(entry.get("role")),
                content=_build_message_payload(text),
            )

        client.beta.threads.messages.create(
            thread_id=thread.id,
            role="user",
            content=_build_message_payload(clean_message),
        )

        run_kwargs = {
            "thread_id": thread.id,
            "assistant_id": assistant_id,
        }
        if prompt:
            run_kwargs["instructions"] = prompt

        run = client.beta.threads.runs.create(**run_kwargs)

        polls = 0
        while True:
            status = run.status
            if status == "completed":
                break
            if status == "requires_action":
                raise OpenAIConnectionError(
                    "Assistant benötigt eine Tool-Ausführung, die aktuell nicht unterstützt wird."
                )
            if status in {"failed", "cancelled", "expired"}:
                raise OpenAIConnectionError(f"Assistant-Run nicht erfolgreich ({status}).")

            polls += 1
            if polls > DEFAULT_ASSISTANT_MAX_POLLS:
                raise OpenAIConnectionError("Assistant-Antwort hat das Zeitlimit überschritten.")

            time.sleep(max(DEFAULT_ASSISTANT_POLL_INTERVAL, 0.1))
            run = client.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)

        messages_page = client.beta.threads.messages.list(
            thread_id=thread.id,
            order="desc",
            limit=10,
        )

        for message in messages_page.data:
            if getattr(message, "role", None) != "assistant":
                continue

            parts: list[str] = []
            for block in getattr(message, "content", []) or []:
                block_type = getattr(block, "type", None)
                if block_type == "text":
                    text_value = getattr(getattr(block, "text", None), "value", "")
                    if text_value:
                        parts.append(text_value)
            if parts:
                text = "\n".join(part.strip() for part in parts if part.strip()).strip()
                if text:
                    return text

        raise OpenAIConnectionError("Assistant lieferte keine Text-Antwort.")
    except OpenAIConnectionError:
        raise
    except Exception as exc:  # pragma: no cover - openai raises various subclasses
        raise OpenAIConnectionError(f"OpenAI Anfrage fehlgeschlagen: {exc}") from exc
