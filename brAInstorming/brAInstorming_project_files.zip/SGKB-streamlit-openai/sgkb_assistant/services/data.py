from __future__ import annotations

from typing import Dict, Optional

import pandas as pd
import streamlit as st

from sgkb_assistant.constants import DEFAULT_TRANSACTIONS, TREND_SERIES


@st.cache_data
def load_transactions() -> pd.DataFrame:
    df = pd.DataFrame(DEFAULT_TRANSACTIONS)
    return _normalize_default_transactions(df)


def _normalize_default_transactions(df: pd.DataFrame) -> pd.DataFrame:
    normalized = df.copy()
    normalized["date"] = pd.to_datetime(normalized["date"], format="%Y-%m-%d", errors="coerce")
    normalized = normalized.dropna(subset=["date"])

    normalized["amount"] = pd.to_numeric(normalized.get("amount"), errors="coerce").fillna(0.0)
    normalized["merchant"] = normalized.get("merchant", pd.Series(dtype=object)).apply(
        _clean_required_string, fallback="Unbekannte Gegenpartei"
    )
    normalized["category"] = normalized.get("category", pd.Series(dtype=object)).apply(
        _clean_required_string, fallback="Unbekannt"
    )
    if "sub" in normalized:
        normalized["sub"] = normalized["sub"].apply(_clean_optional_string)
    else:
        normalized["sub"] = pd.Series([None] * len(normalized), dtype=object)
    if "currency" not in normalized:
        normalized["currency"] = "CHF"
    normalized["currency"] = normalized["currency"].apply(_clean_required_string, fallback="CHF")
    if "id" not in normalized:
        normalized["id"] = normalized.index

    normalized["month"] = normalized["date"].dt.to_period("M")
    return normalized[["id", "date", "merchant", "category", "sub", "amount", "currency", "month"]]

def _clean_optional_string(value: object) -> Optional[str]:
    if isinstance(value, str):
        cleaned = value.strip()
        return cleaned or None
    return None


def _clean_required_string(value: object, fallback: str = "") -> str:
    if isinstance(value, str):
        cleaned = value.strip()
        if cleaned:
            return cleaned
        return fallback
    if pd.isna(value):
        return fallback
    return str(value)


def _classify_mobility(merchant: str) -> str:
    text = merchant.lower()
    ov_keywords = (
        "sbb",
        "bahn",
        "bus",
        "vbz",
        "ostwind",
        "postauto",
        "tram",
        "öbb",
    )
    auto_keywords = (
        "shell",
        "avia",
        "bp",
        "coop pronto",
        "migrol",
        "agrola",
        "garage",
        "parking",
        "tank",
        "esso",
    )
    if any(keyword in text for keyword in ov_keywords):
        return "ÖV"
    if any(keyword in text for keyword in auto_keywords):
        return "Auto"
    return "Sonstiges"


@st.cache_data
def load_trend() -> pd.DataFrame:
    return pd.DataFrame(TREND_SERIES)


def compute_summary(df: pd.DataFrame) -> Dict[str, object]:
    income = float(df.loc[df["amount"] > 0, "amount"].sum())
    spend = float(-df.loc[df["amount"] < 0, "amount"].sum())
    if df.empty:
        return {"income": 0.0, "spend": 0.0, "start": None, "end": None}
    start = df["date"].min()
    end = df["date"].max()
    return {"income": income, "spend": spend, "start": start, "end": end}


def compute_positive_month_streak(df: pd.DataFrame) -> int:
    if df.empty or "month" not in df:
        return 0

    monthly_balances = df.groupby("month")["amount"].sum().sort_index()

    streak = 0
    for balance in monthly_balances:
        if balance > 0:
            streak += 1
        else:
            streak = 0

    return int(streak)


def aggregate_by_category(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(columns=["category", "value"])
    spend = df[df["amount"] < 0].copy()
    if spend.empty:
        return pd.DataFrame(columns=["category", "value"])
    spend["category"] = spend["category"].fillna("Unbekannt")
    grouped = spend.groupby("category", as_index=False)["amount"].sum()
    grouped["value"] = grouped["amount"].abs()
    grouped = grouped.drop(columns=["amount"]).sort_values("value", ascending=False)
    return grouped


def aggregate_mobility(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame({"sub": ["ÖV", "Auto"], "value": [0.0, 0.0]})

    spend = df[df["amount"] < 0].copy()
    if spend.empty:
        return pd.DataFrame({"sub": ["ÖV", "Auto"], "value": [0.0, 0.0]})

    if "Mobilität" in spend["category"].unique():
        mobility = spend[spend["category"] == "Mobilität"].copy()
        mobility["sub"] = mobility.get("sub", pd.Series(dtype=object)).apply(_clean_optional_string).fillna("Gesamt")
    else:
        mobility = spend.copy()
        mobility["sub"] = mobility["merchant"].apply(_classify_mobility)
        mobility = mobility[mobility["sub"] != "Sonstiges"]

    if mobility.empty:
        return pd.DataFrame({"sub": ["ÖV", "Auto"], "value": [0.0, 0.0]})

    mobility["value"] = mobility["amount"].abs()
    grouped = mobility.groupby("sub", as_index=False)["value"].sum()
    totals = {label: 0.0 for label in ("ÖV", "Auto")}
    for _, row in grouped.iterrows():
        label = row.get("sub")
        if label in totals:
            totals[label] = float(row["value"])
    return pd.DataFrame({"sub": list(totals.keys()), "value": list(totals.values())})
