from __future__ import annotations

from typing import Dict, Tuple

import streamlit as st

from sgkb_assistant.constants import DEFAULT_USERS


def authenticate(contract_number: str, pin: str) -> Dict[str, object] | None:
    contract_number = contract_number.strip()
    pin = pin.strip()
    users = st.session_state.get("users", list(DEFAULT_USERS))
    for user in users:
        if user["contract_number"] == contract_number and user["pin"] == pin:
            return user
    return None


def register_user(contract_number: str, pin: str, display_name: str) -> Tuple[bool, Dict[str, object] | str]:
    contract_number = contract_number.strip()
    pin = pin.strip()
    display_name = display_name.strip()

    if not contract_number or not pin:
        return False, "Bitte Vertragsnummer und PIN angeben."

    users = st.session_state.setdefault("users", list(DEFAULT_USERS))
    for user in users:
        if user["contract_number"] == contract_number:
            return False, "Vertragsnummer ist bereits registriert."

    if display_name:
        display = display_name
    elif contract_number:
        display = f"Kunde {contract_number[-4:]}"
    else:
        display = "Neuer Kunde"

    new_user = {
        "contract_number": contract_number,
        "pin": pin,
        "display_name": display,
        "sgkb_points": 0,
    }
    users.append(new_user)
    st.session_state["users"] = users
    return True, new_user
