from __future__ import annotations

import argparse
import os

from watsonx import (
    DEFAULT_MODEL_ID,
    REGION,
    TEXT_GENERATION_URL,
    WatsonxError,
    generate_watsonx_response,
    load_credentials,
)

DEFAULT_PROMPT = os.getenv("IBM_WATSONX_PROMPT", "Du bist ein nützlicher Assistent, der dem User hilft ein bewusstsein für seine Finanzen zu entwickeln.")


def main(prompt: str, model_id: str) -> None:
    try:
        _, project_id, space_id = load_credentials()
        generated = generate_watsonx_response(prompt, model_id=model_id)
    except WatsonxError as exc:
        raise RuntimeError(str(exc)) from exc

    print(f"Region: {REGION}")
    print(f"Endpoint: {TEXT_GENERATION_URL}")
    print(f"Model: {model_id}")
    scope_text = project_id or space_id or "unbekannt"
    print(f"Project/Space: {scope_text}")
    print(f"Prompt: {prompt}")
    print("Antwort:")
    print(generated)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Einfacher watsonx.ai Textgenerations-Test")
    parser.add_argument("prompt", nargs="?", default=DEFAULT_PROMPT, help="Text der an das LLM gesendet wird")
    parser.add_argument(
    "--model",
    default="ibm/granite-3-3-8b-instruct",
    help="Optionales Modell (Standard: ibm/granite-3-3-8b-instruct), z. B. granite-13b-instruct-v2, granite-7b-lab etc."
)
    args = parser.parse_args()

    main(args.prompt, args.model)
