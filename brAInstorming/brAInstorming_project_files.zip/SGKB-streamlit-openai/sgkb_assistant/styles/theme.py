from __future__ import annotations

from string import Template
from typing import Dict, Iterable, Tuple

import streamlit as st


GLOBAL_COLORS: Dict[str, str] = {
    "brand": "#009639",
    "brand_dark": "#007a53",
    "muted": "#5f6367",
    "muted_soft": "#9ca3af",
    "card": "#ffffff",
    "border": "#cad8cf",
    "bg": "#f3f6f4",
    "bg_hero": "#f9fbfa",
    "bg_depth": "#e7efe9",
    "negative": "#ef6f42",
    "positive": "#409bd0",
}

_ALPHA_COLORS: Dict[str, str] = {
    "brand_soft": "rgba(0,150,57,0.08)",
    "brand_soft_strong": "rgba(0,150,57,0.18)",
    "brand_outline": "rgba(0,150,57,0.2)",
    "positive_soft": "rgba(64,155,208,0.12)",
    "negative_soft": "rgba(239,111,66,0.12)",
}


def _hex_to_rgb(value: str) -> Tuple[int, int, int]:
    value = value.strip().lstrip("#")
    if len(value) != 6:
        raise ValueError(f"Expected 6 hex characters, got '{value}'")
    return tuple(int(value[i : i + 2], 16) for i in range(0, 6, 2))


def _rgb_to_hex(rgb: Iterable[float]) -> str:
    r, g, b = (max(0, min(255, int(round(channel)))) for channel in rgb)
    return f"#{r:02x}{g:02x}{b:02x}"


def _mix(color_a: str, color_b: str, ratio: float) -> str:
    ratio = max(0.0, min(1.0, ratio))
    r1, g1, b1 = _hex_to_rgb(color_a)
    r2, g2, b2 = _hex_to_rgb(color_b)
    return _rgb_to_hex(
        (
            r1 * (1 - ratio) + r2 * ratio,
            g1 * (1 - ratio) + g2 * ratio,
            b1 * (1 - ratio) + b2 * ratio,
        )
    )


def _tint(color: str, amount: float) -> str:
    return _mix(color, "#ffffff", amount)


def _shade(color: str, amount: float) -> str:
    return _mix(color, "#000000", amount)


DEFAULT_CHART_PALETTE: Tuple[str, ...] = tuple(
    dict.fromkeys(
        [
            GLOBAL_COLORS["brand"],
            _tint(GLOBAL_COLORS["brand"], 0.3),
            _shade(GLOBAL_COLORS["brand"], 0.18),
            GLOBAL_COLORS["brand_dark"],
            _tint(GLOBAL_COLORS["brand_dark"], 0.25),
            GLOBAL_COLORS["positive"],
            _tint(GLOBAL_COLORS["positive"], 0.28),
            _shade(GLOBAL_COLORS["positive"], 0.12),
            GLOBAL_COLORS["negative"],
            _tint(GLOBAL_COLORS["negative"], 0.28),
            _shade(GLOBAL_COLORS["negative"], 0.12),
            _tint(GLOBAL_COLORS["muted"], 0.35),
            _shade(GLOBAL_COLORS["muted"], 0.18),
        ]
    )
)

_CSS_TEMPLATE = Template(
    """
<style>
:root {
  /* Corporate */
  --brand:${brand};        /* SGKB-Grün */
  --brand-dark:${brand_dark};   /* dunkleres Grün */

  /* Neutrale Basisfarben */
  --muted:${muted};        /* Stein (Grau, primär für Texte/Labels) */
  --muted-soft:${muted_soft};
  --card:${card};         /* Weiß für Karten */
  --border:${border};       /* heller Rahmen, neutral */
  --bg:${bg};           /* Hintergrundfläche */
  --bg-hero:${bg_hero};
  --bg-depth:${bg_depth};
  --brand-soft:${brand_soft};
  --brand-soft-strong:${brand_soft_strong};
  --brand-outline:${brand_outline};
  --positive-soft:${positive_soft};
  --negative-soft:${negative_soft};

  /* Statusfarben */
  --negative:${negative};     /* Flamme (kräftiges Orange/Rot für Minus) */
  --positive:${positive};     /* Luft (Blau für Plus-Werte) */

  /* Layout */
  --nav-height:72px;
  --nav-offset:calc(var(--nav-height) + 32px);
}

#MainMenu, footer { display:none !important; }
[data-testid="stHeader"] { display:none; }

[data-testid="stAppViewContainer"] > .main {
  background: linear-gradient(180deg,var(--bg-hero) 0%, var(--bg) 45%, var(--bg-depth) 100%);
  padding-top:0;
}

blockquote, .muted { color: var(--muted); }

/* === Komponenten (unverändert) === */
.login-card .stForm {
  border-radius:18px; border:1px solid var(--border); background:var(--card);
  padding:28px 32px; box-shadow:0 14px 32px rgba(0,100,60,0.08);
}
.login-card .stForm label{ font-weight:600; font-size:13px; color:var(--muted); }
.login-card .stForm input{ border-radius:10px !important; border:1px solid var(--border); }
.login-card .stForm button[kind="primary"]{ background:var(--brand); border-color:var(--brand); }
.login-card .stForm button[kind="primary"]:hover{ background:var(--brand-dark); }

.metric-card{ border-radius:18px; padding:18px; background:var(--card); border:1px solid var(--border); box-shadow:0 12px 28px rgba(0,60,40,0.08); }
.metric-card h4{ margin:0; font-size:13px; color:var(--muted); text-transform:uppercase; letter-spacing:0.08em; }
.metric-card .value{ margin-top:6px; font-size:26px; font-weight:700; }
.metric-card .range{ margin-top:4px; font-size:12px; color:var(--muted); }

.tx-list{ display:flex; flex-direction:column; gap:12px; }
.tx-row{
  display:flex; justify-content:space-between; align-items:center; padding:12px 18px;
  border-radius:14px; border:1px solid var(--border); background:var(--card);
  box-shadow:0 8px 18px rgba(0,60,40,0.05);
}
.tx-row .merchant{ font-weight:700; }
.tx-row .meta{ font-size:12px; color:var(--muted); }
.tx-row .amount{ font-weight:700; font-size:16px; }
.tx-row .amount.minus{ color:var(--negative); }
.tx-row .amount.plus{ color:var(--positive); }
.tx-row .badge{
  display:inline-block; margin-left:6px; padding:2px 8px; border-radius:999px;
  border:1px solid var(--brand-outline); background:var(--brand-soft);
  color:var(--brand); font-size:11px;
}

.todo-board{ display:flex; flex-direction:column; gap:12px; }
.todo-row{
  display:flex; justify-content:space-between; align-items:center; padding:14px 18px;
  border-radius:14px; border:1px solid var(--border); background:var(--card);
  box-shadow:0 8px 18px rgba(0,60,40,0.05);
}
.todo-row .due{ font-size:12px; color:var(--muted); margin-top:4px; }
.todo-row button{
  border-radius:999px; border:1px solid var(--border);
  background:var(--brand-soft); color:var(--brand-dark); font-weight:600;
}
.todo-row button:hover{ background:var(--brand-soft-strong); }

.chart-card{ border-radius:18px; padding:18px; background:var(--card); border:1px solid var(--border); box-shadow:0 12px 28px rgba(0,60,40,0.08); }
.chart-card h3{ margin-top:0; }

.block-container{
  padding-top:0 !important;
}

.top-nav{
  display:flex; align-items:center; justify-content:space-between; gap:18px;
  padding:14px 24px; position:sticky; top:0;
  min-height:var(--nav-height);
  background:var(--card); border-radius:16px; box-shadow:0 14px 32px rgba(0,60,40,0.12);
  z-index:100;
  margin-bottom:calc(var(--nav-offset) - var(--nav-height));
}
.top-nav__text h3{ margin:0; }
.top-nav__text p{ margin:4px 0 0; color:var(--muted); }
.top-nav__logo{ display:flex; align-items:center; justify-content:flex-end; min-width:120px; }
.top-nav__logo img{ max-height:44px; width:auto; }

[data-testid="stSidebar"] > div {
  padding-top:var(--nav-offset);
}

@media (max-width: 768px) {
  .top-nav{
    padding:12px 18px;
    width:calc(100% - 32px);
  }
  .top-nav__text h3{ font-size:18px; }
  .top-nav__text p{ font-size:13px; }
}
</style>
"""
)

GLOBAL_CSS = _CSS_TEMPLATE.substitute(
    {
        "brand": GLOBAL_COLORS["brand"],
        "brand_dark": GLOBAL_COLORS["brand_dark"],
        "muted": GLOBAL_COLORS["muted"],
        "muted_soft": GLOBAL_COLORS["muted_soft"],
        "card": GLOBAL_COLORS["card"],
        "border": GLOBAL_COLORS["border"],
        "bg": GLOBAL_COLORS["bg"],
        "bg_hero": GLOBAL_COLORS["bg_hero"],
        "bg_depth": GLOBAL_COLORS["bg_depth"],
        "brand_soft": _ALPHA_COLORS["brand_soft"],
        "brand_soft_strong": _ALPHA_COLORS["brand_soft_strong"],
        "brand_outline": _ALPHA_COLORS["brand_outline"],
        "positive_soft": _ALPHA_COLORS["positive_soft"],
        "negative_soft": _ALPHA_COLORS["negative_soft"],
        "negative": GLOBAL_COLORS["negative"],
        "positive": GLOBAL_COLORS["positive"],
    }
)
def inject_css() -> None:
    st.markdown(GLOBAL_CSS, unsafe_allow_html=True)
