from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from sgkb_assistant.styles.theme import DEFAULT_CHART_PALETTE

PACKAGE_ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_ROOT.parent
CHATBOT_AVATAR_PATH = PROJECT_ROOT / "mika.png"

CATEGORIES: List[str] = [
    "Einnahmen",
    "Zahlungen",
    "Gastronomie",
    "Mobilität",
    "Unterhaltung",
    "Persönliches",
    "Lebensmittel",
    "Gesundheit",
    "Shopping",
    "Reisen",
    "Bargeldbezug",
    "Sparen&Anlegen",
    "Wohnen",
    "Steuern",
    "Allgemeines",
]

PALETTE: List[str] = list(DEFAULT_CHART_PALETTE)

### Testing Data

DEFAULT_TRANSACTIONS: List[Dict[str, object]] = [
    {"id": 1, "date": "2025-09-12", "merchant": "Coop Pronto", "category": "Lebensmittel", "amount": -13.55, "currency": "CHF"},
    {"id": 2, "date": "2025-09-11", "merchant": "SBB", "category": "Mobilität", "sub": "ÖV", "amount": -23.20, "currency": "CHF"},
    {"id": 3, "date": "2025-09-10", "merchant": "Netflix", "category": "Unterhaltung", "amount": -18.90, "currency": "CHF"},
    {"id": 4, "date": "2025-09-10", "merchant": "Arbeitgeber", "category": "Einnahmen", "amount": 3250.00, "currency": "CHF"},
    {"id": 5, "date": "2025-09-09", "merchant": "Galaxus", "category": "Shopping", "amount": -210.00, "currency": "CHF"},
    {"id": 6, "date": "2025-09-08", "merchant": "Hausmiete", "category": "Wohnen", "amount": -1200.00, "currency": "CHF"},
    {"id": 7, "date": "2025-09-07", "merchant": "CSS Versicherung", "category": "Gesundheit", "amount": -120.00, "currency": "CHF"},
    {"id": 8, "date": "2025-09-06", "merchant": "TWINT Cash", "category": "Bargeldbezug", "amount": -50.00, "currency": "CHF"},
    {"id": 9, "date": "2025-09-04", "merchant": "Flixbus", "category": "Reisen", "amount": -39.00, "currency": "CHF"},
    {"id": 10, "date": "2025-09-03", "merchant": "Steueramt", "category": "Steuern", "amount": -300.00, "currency": "CHF"},
    {"id": 11, "date": "2025-09-02", "merchant": "Shell", "category": "Mobilität", "sub": "Auto", "amount": -70.00, "currency": "CHF"},
    {"id": 12, "date": "2025-09-01", "merchant": "Krankenkasse Rückerst.", "category": "Zahlungen", "amount": 45.00, "currency": "CHF"},
]

TREND_SERIES: List[Dict[str, object]] = [
    {"month": "2025-04", "value": 1120},
    {"month": "2025-05", "value": 980},
    {"month": "2025-06", "value": 1250},
    {"month": "2025-07", "value": 1030},
    {"month": "2025-08", "value": 1390},
    {"month": "2025-09", "value": 1210},
]

DEFAULT_TODO_ITEMS: List[Dict[str, object]] = [
    {"text": "Budget-Report für Oktober prüfen", "due_date": "2025-09-15"},
    {"text": "Sitzung mit Berater organisieren", "due_date": "2025-09-18"},
    {"text": "eBill Freigaben kontrollieren", "due_date": "2025-09-20"},
]

DEFAULT_USERS: List[Dict[str, object]] = [
    {
        "contract_number": "70010001",
        "pin": "1357",
        "display_name": "Max Muster",
        "sgkb_points": 1820,
    },
    {
        "contract_number": "70010002",
        "pin": "2468",
        "display_name": "Anna Beispiel",
        "sgkb_points": 2435,
    },
    {
        "contract_number": "70010003",
        "pin": "0000",
        "display_name": "Test Benutzer",
        "sgkb_points": 640,
    },
    {
        "contract_number": "1234",
        "pin": "1234",
        "display_name": "Max Muster",
        "sgkb_points": 1820,
    },
]
