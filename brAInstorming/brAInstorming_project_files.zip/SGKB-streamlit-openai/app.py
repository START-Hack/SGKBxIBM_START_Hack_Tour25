from __future__ import annotations

from sgkb_assistant.app import main


if __name__ == "__main__":
    main()
