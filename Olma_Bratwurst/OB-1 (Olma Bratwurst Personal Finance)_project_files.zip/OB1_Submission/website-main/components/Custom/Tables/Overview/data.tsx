export const statusOptions = [
  {
    label: "cardtrx",
    value: "cardtrx",
    //   icon: ArrowDownIcon,
  },
  {
    label: "pay",
    value: "pay",
    //   icon: ArrowRightIcon,
  },
  {
    label: "inpay",
    value: "inpay",
    //   icon: ArrowRightIcon,
  },
  {
    label: "cop",
    value: "cop",
    //   icon: ArrowRightIcon,
  },
  {
    label: "cord",
    value: "cord",
    //   icon: ArrowRightIcon,
  },
  {
    label: "intr",
    value: "intr",
    //   icon: ArrowRightIcon,
  },
  {
    label: "xfermon",
    value: "xfermon",
    //   icon: ArrowRightIcon,
  },
];
