import SqlChat from "@/components/Chat/SqlChat";



export default function ChatPage() {
  return (
    <main className="h-screen w-full bg-gray-100">
      <SqlChat />
    </main>
  );
}
