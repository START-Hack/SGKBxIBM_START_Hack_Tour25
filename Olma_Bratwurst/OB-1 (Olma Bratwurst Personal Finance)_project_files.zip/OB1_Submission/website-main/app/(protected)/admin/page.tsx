export default async function ProtectedPage() {
  return <div>Welcome</div>;
}
