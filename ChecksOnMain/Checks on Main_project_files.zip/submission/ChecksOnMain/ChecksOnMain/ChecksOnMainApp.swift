//
//  ChecksOnMainApp.swift
//  ChecksOnMain
//
//  Created by Anton Baranov on 19.09.25.
//

import SwiftUI

@main
struct ChecksOnMainApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
