import os, json
from dotenv import load_dotenv
from ibm_watsonx_ai import APIClient, Credentials
from ibm_watsonx_ai.foundation_models import ModelInference

from fastapi import FastAPI
from pydantic import BaseModel

load_dotenv()

credentials = Credentials(
    url = "https://eu-de.ml.cloud.ibm.com",
    api_key = os.getenv("API_KEY"),
)

client = APIClient(credentials)
client.set.default_space(os.getenv("SPACE_TEST"))

llama_model = "meta-llama/llama-3-2-90b-vision-instruct"

model = ModelInference(
    model_id=llama_model,
    api_client=client,
)

categories_list = [
    "RENT",
    "UTILITIES",
    "DEBT REPAYMENT",
    "GROCERIES",
    "CAR AND FUEL",
    "PUBLIC TRANSPORT",
    "RESTAURANTS",
    "ENTERTAINMENT",
    "SUBSCRIPTION SERVICES",
    "HEALTH INSURANCE",
    "VACATION",
    "GIFTS AND DONATIONS",
    "INCOME",
    "CASH WITHDRAWAL"
]

def classify(transaction) -> str:
    system_prompt = f"""
Role: 
Your are an AI agent responsible for classifying financial transactions of a personal bank account
into different categories.

Task:
You should classify each transaction into one of the following categories.
Only answer with the correct category and nothing more. Give no reasons for your decision.
If there is absolutely no matching category answer with "MISCELLANEOUS".

Classification categories:
{"\n".join(["- " + category for category in categories_list])}

Context:
About each transaction these attributes are given with the decribed mening:
direction - 1 for incoming money, 2 for outgoing money
amount - transaction amount
currency - name of the currency
purpose - to whom the transaction was made and for what reason
"""

    prompt = f"""
Transaction information for classification:
{"\n".join([key + ": " + transaction[key] for key in transaction.keys()])}
"""
    
    messages = [
        {
            "role": "system",
            "content": [
            {
                "type": "text",
                "text": system_prompt
            }
            ]
        },
        {
            "role": "user",
            "content": [
            {
                "type": "text",
                "text": prompt
            }
            ]
        }
    ]

    response = model.chat(messages=messages)
    category = response["choices"][0]["message"]["content"]
    return category

class Transaction(BaseModel):
    direction: str
    amount: str
    currency: str
    purpose: str

class Chat(BaseModel):
    reset: bool
    message: str
    contacts: str
    transactions: str

app = FastAPI()

@app.post("/api/classify")
async def classify_transaction(transaction: Transaction):
    return classify(transaction.dict())

@app.get("/api/categories")
async def categories():
    return categories_list

current_chat = None

@app.post("/api/chat")
async def chat(chat: Chat):
    global current_chat

    system_prompt = f"""
Role:
You are an AI agent responsible for helping a user with their personal banking.
Your answers should only be syntactically correct json. The json should be stringifyied and
not contain any newline characters or escape sequences.

You are helpful, respectful and honest. Always answer as helpfully as possible, while being safe. 
Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. Please ensure that your responses are socially unbiased and positive in nature.
If a question does not make any sense, or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, please don't share false information.

Tasks:
For every message of the user, you have to decide if the user is asking a general
question or if the user wants to initiate a payment request.
If the user is asking a general question, answer politely and helpful.
Answer in json with these attributes set:
    type: "question",
    message: "<message>"

If the user wants to initiate a payment, find the contact from the contact list,
which the user most likely wants to initiate the payment to.
Split amount and currency into the correct json attributes.
Also make a short summary of the purpose of the payment.
Answer in json with these attributes set:
    type: "request",
    contact_id: "<contact id>",
    amount: "<amount>"
    currency: "<currency>"
    purpose: "<purpose of payment>"

Context:
This is the contact list:
{chat.contacts}

This is the last of past transactions:
{chat.transactions}

These are the attributes of each transaction:
direction - 1 for incoming money, 2 for outgoing money
amount - transaction amount
currency - name of the currency
purpose - to whom the transaction was made and for what reason
"""

    prompt = f"""
User message:
{chat.message}
"""

    if chat.reset:
        current_chat = [
            {
                "role": "system",
                "content": [
                {
                    "type": "text",
                    "text": system_prompt
                }
                ]
            },
            {
                "role": "user",
                "content": [
                {
                    "type": "text",
                    "text": prompt
                }
                ]
            }
        ]
    else:
        current_chat.append({
            "role": "user", 
            "content": [
            {
                "type": "text",
                "text": chat.message
            }
            ]
        })
    
    response = model.chat(messages=current_chat)
    text = response["choices"][0]["message"]["content"]
    json_val = json.loads(text)

    if json_val["type"] == "question":
        deployment_id="1bf7d42e-8df4-4b98-b269-c2f35f07b1c2"
        payload = {"messages":[{"content": chat.message,"role":"user"}]}
        response = client.deployments.run_ai_service(deployment_id, payload)
        text = response["choices"][0]["message"]["content"]
        return {"type": "question", "message": text}

    return json_val
