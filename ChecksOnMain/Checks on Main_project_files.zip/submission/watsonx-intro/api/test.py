import os
from dotenv import load_dotenv
from ibm_watsonx_ai import APIClient, Credentials

load_dotenv()

credentials = Credentials(
    url = "https://eu-de.ml.cloud.ibm.com",
    api_key = os.getenv("API_KEY")
)

client = APIClient(credentials)
deployment_id="1bf7d42e-8df4-4b98-b269-c2f35f07b1c2"
payload = {"messages":[{"content":"Welche Angebote gibt es für Kinder bei der St. Gallen Kantonalbank?","role":"user"}]}
response = client.deployments.run_ai_service(deployment_id, payload)
text = response["choices"][0]["message"]["content"]
print(text)
