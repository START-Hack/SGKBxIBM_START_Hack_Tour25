package com.studentbrain.backend.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.studentbrain.backend.client.MyClient;
import com.studentbrain.backend.dto.CreateTransactionDTO;
import com.studentbrain.backend.dto.InitTransactionDTO;
import com.studentbrain.backend.dto.RequestsAI.CategorizeRequest;
import com.studentbrain.backend.enums.Category;
import com.studentbrain.backend.model.Account;
import com.studentbrain.backend.model.Transaction;
import com.studentbrain.backend.repository.AccountRepository;
import com.studentbrain.backend.repository.TransactionRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionService {
    private final AccountRepository accountRepo;
    private final TransactionRepository txRepo;
    private final MyClient myClient;
    private final PythonCallerService pythonCallerService;

    public TransactionService(AccountRepository accountRepo, TransactionRepository txRepo, MyClient myClient, PythonCallerService pythonCallerService) {
        this.accountRepo = accountRepo;
        this.txRepo = txRepo;
        this.myClient = myClient;
        this.pythonCallerService = pythonCallerService;
    }
    @Transactional
    public Transaction initTransaction(InitTransactionDTO dto) {
        //need to choose the category with IBM
        Account sender = accountRepo.findById(dto.accountId())
                .orElseThrow(() -> new EntityNotFoundException("Sender not found: " + dto.accountId()));

        Account receiver = accountRepo.findById(dto.receiverId())
                .orElseThrow(() -> new EntityNotFoundException("Receiver not found: " + dto.receiverId()));

        // TODO: choose category via your IBM/Python classifier and check the format to do so!

        Category category = Category.UNCATEGORIZED;

        // direction: 1 = incoming, 2 = outgoing (consider using an enum)
        Transaction tOut = new Transaction(dto.amount(), sender, 2, dto.purpose(), receiver.getName(), category);
        Transaction tIn  = new Transaction(dto.amount(), receiver, 1, dto.purpose(), sender.getName(), category);

        txRepo.saveAll(List.of(tOut, tIn)); // atomic because of @Transactional

        // Return whichever you prefer; here we return the "initiator/sender" transaction
        return tOut;
    }

    @Transactional
    public Transaction createTransaction(CreateTransactionDTO dto){
        // TODO: choose category via your IBM/Python classifier else undefined
        Category category = Category.UNCATEGORIZED;
        Account account = accountRepo.findById(dto.accountId())
                .orElseThrow(() -> new EntityNotFoundException("Account not found: " + dto.accountId()));

        CategorizeRequest cr = new CategorizeRequest(String.valueOf(dto.direction()), String.valueOf(dto.amount()), "CHF", dto.purpose());
        System.out.println(cr);

        String category1;
        /*category1 = myClient.getCategory(cr);*/
        category1 = pythonCallerService.sendToPython(cr).toString();
        System.out.println(category1);

        // direction: 1 = incoming, 2 = outgoing (consider using an enum)
        Transaction t = new Transaction(dto.amount(), account, dto.direction(), dto.purpose(), dto.counterParty(), category);

        txRepo.save(t);

        // Return whichever you prefer; here we return the "initiator/sender" transaction
        return t;
    }
}