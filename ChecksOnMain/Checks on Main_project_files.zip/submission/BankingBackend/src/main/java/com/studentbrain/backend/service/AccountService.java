package com.studentbrain.backend.service;

import com.studentbrain.backend.dto.*;
import com.studentbrain.backend.model.Account;
import com.studentbrain.backend.model.SubAccount;
import com.studentbrain.backend.repository.AccountRepository;
import com.studentbrain.backend.repository.SubAccountRepository;
import com.studentbrain.backend.repository.UserGroupRepository;
import jakarta.persistence.EntityExistsException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AccountService {
    private final AccountRepository accountRepository;
    private final SubAccountService subAccountService;
    private final SubAccountRepository subAccountRepository;
    private final UserGroupRepository userGroupRepository;

    public CreateAccountDto getAccountState(long id) {
        Optional<Account> searchAccount = accountRepository.findById(id);
        if (searchAccount.isPresent()) {
            CreateAccountDto createAccountDto = new CreateAccountDto(searchAccount.get().getName(), searchAccount.get().getSaldo());
            return createAccountDto;
        } else throw new EntityExistsException("Account not found by id: " + id);
    }

    public CreateAccountDto createAccount(CreateAccountDto createAccountDto) {
        Account account = new Account(createAccountDto.name(), createAccountDto.saldo());
        accountRepository.save(account);
        return createAccountDto;
    }

    public SubAccount createSubAccount(Long id, SubAccountDto subAccountDto) {
        Optional<Account> account = accountRepository.findById(id);
        if (account.isPresent()) {
            SubAccount subAccount = subAccountService.createSubAccount(subAccountDto);
            subAccount.setAccount(account.get());
            subAccount.setDescription(subAccountDto.description());
            subAccount.setTargetDate(subAccount.getTargetDate());
            subAccountRepository.save(subAccount);
            return subAccount;
        }
        throw new IllegalArgumentException("Account is not existing");
    }

    public boolean changeSaldo(Long id, float amount) {
        Optional<Account> account = accountRepository.findById(id);
        if (account.isPresent()) {
            if (amount > 0) {
                account.get().setSaldo(account.get().getSaldo() + amount);
                return true;
            } else {
                if (account.get().getSaldo() >= amount) {
                    account.get().setSaldo(account.get().getSaldo() + amount);
                    return true;
                }
            }
        }
        return false;
    }

    public float requestSavingSuggestion(RequestSubAccountRateDto requestSubAccountRateDto) {
        Optional<Account> mainAccount = accountRepository.findById(requestSubAccountRateDto.mainAccountId());
        if (mainAccount.isPresent()) {
            List<SubAccount> savingAccounts = mainAccount.get().getSubAccounts();
            for (SubAccount subAccount : savingAccounts) {
                if (subAccount.getId().equals(requestSubAccountRateDto.subAccountId())) {
                    return subAccount.calculateDailyRecommendation();
                }
            }
        }
        throw new IllegalArgumentException("Subaccount not found id: " + requestSubAccountRateDto.subAccountId());
    }

    public SubAccountResponseDto increaseSubAccount(long accountId, long subAccountId, float value) {
        Account mainAccount = accountRepository.findById(accountId)
                .orElseThrow(() -> new IllegalArgumentException("Mainaccount not found: " + accountId));

        SubAccount subAccount = subAccountRepository.findById(subAccountId)
                .orElseThrow(() -> new IllegalArgumentException("Subaccount not found: " + subAccountId));


        if (mainAccount.getSaldo() < value) {
            throw new IllegalArgumentException("Not enough balance in main account");
        }

        float newAmount = subAccount.getCurrentAmount() + value;

        if (newAmount > subAccount.getGoalAmount()) {
            float allowed = subAccount.getGoalAmount() - subAccount.getCurrentAmount();

            subAccount.setCurrentAmount(subAccount.getGoalAmount());   // SubAccount auf max setzen
            mainAccount.setSaldo(mainAccount.getSaldo() - allowed);    // nur den allowed-Betrag abziehen
        } else {
            subAccount.setCurrentAmount(newAmount);
            mainAccount.setSaldo(mainAccount.getSaldo() - value);
        }

        accountRepository.save(mainAccount);
        subAccountRepository.save(subAccount);

        return new SubAccountResponseDto(
                subAccount.getName(),
                subAccount.getCurrentAmount(),
                subAccount.getGoalAmount()
        );
    }

    public void delegateMoney(Long id) {
        List<SubAccount> subAccounts = subAccountRepository.findByAccount_Id(id);
        Account mainAccount = accountRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Main account not found with id: " + id));

        float mainAmount = mainAccount.getSaldo();

        for (SubAccount creditedAccount : subAccounts) {
            float creditRate = creditedAccount.calculateSavingRateWithProvidedValue(mainAmount);

            if (creditRate <= 0) {
                continue;
            }

            float availableSpace = creditedAccount.getGoalAmount() - creditedAccount.getCurrentAmount();
            if (availableSpace <= 0) {
                continue;
            }

            float transferAmount = Math.min(creditRate, availableSpace);

            if (mainAccount.getSaldo() < transferAmount) {
                continue;
            }

            mainAccount.setSaldo(mainAccount.getSaldo() - transferAmount);
            creditedAccount.setCurrentAmount(creditedAccount.getCurrentAmount() + transferAmount);


            subAccountRepository.save(creditedAccount);
        }

        accountRepository.save(mainAccount);
    }

    public ResponseSubAccountDto getSubAccount(RequestSubAccountRateDto requestSubAccountRateDto) {
        Optional<Account> account = accountRepository.findById(requestSubAccountRateDto.mainAccountId());
        if (account.isPresent()) {
            List<SubAccount> accounts = account.get().getSubAccounts();
            for (SubAccount searchAccount : accounts) {
                if (searchAccount.getId() == requestSubAccountRateDto.subAccountId()) {
                    return new ResponseSubAccountDto(searchAccount.getName(), searchAccount.getCurrentAmount(), searchAccount.getGoalAmount(), searchAccount.getDescription(), searchAccount.getDayLefts());
                }

            }

        }
        throw new IllegalArgumentException("Subaccount not found");
    }

    public List<SubAccountName> getAccounts(Long id) {
        Optional<Account> detectAccount = accountRepository.findById(id);
        if (detectAccount.isPresent()) {
            List<SubAccountName> accountNames = new ArrayList<>();
            for (SubAccount subAccount : detectAccount.get().getSubAccounts()) {
                accountNames.add(new SubAccountName(subAccount.getName()));
            }
            return accountNames;
        }
        throw new IllegalArgumentException("Account not found ");
    }
}
