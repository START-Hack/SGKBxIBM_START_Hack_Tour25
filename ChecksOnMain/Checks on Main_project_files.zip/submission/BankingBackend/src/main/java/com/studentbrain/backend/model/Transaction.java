package com.studentbrain.backend.model;

import com.studentbrain.backend.enums.Category;
import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private Double amount;
    @Enumerated(EnumType.STRING)
    private Category category;
    /**
     * val 1= receiving money
     * val 2= outgoing money
     */
    private int direction;
    private String purpose;
    private String counterParty;
    private LocalDateTime createdAt;

    @ManyToOne
    @JoinColumn(name = "account_id")
    private Account account;
    public Transaction(Double amount, Account account, int direction, String purpose, String counterParty, Category category){
        this.amount = amount;
        this.account = account;
        this.direction = direction;
        this.purpose = purpose;
        this.counterParty = counterParty;
        this.category = category;
        this.createdAt = LocalDateTime.now();
    }

    public Transaction(){
    }
}