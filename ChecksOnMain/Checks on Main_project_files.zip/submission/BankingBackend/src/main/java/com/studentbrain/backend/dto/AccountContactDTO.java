package com.studentbrain.backend.dto;

public record AccountContactDTO (Long id, String name){}

