package com.studentbrain.backend.dto;

public record SubAccountName(String name) {
}
