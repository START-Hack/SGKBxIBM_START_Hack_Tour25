package com.studentbrain.backend.dto;

public record CreateSubAccountDto(long accountId, SubAccountDto subAccountDto) {
}
