package com.studentbrain.backend.dto;

public record RequestSubAccountRateDto(long mainAccountId, long subAccountId ) {
}
