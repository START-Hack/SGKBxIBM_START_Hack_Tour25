package com.studentbrain.backend.dto;

public record CreateAccountDto(String name, float saldo) {}
