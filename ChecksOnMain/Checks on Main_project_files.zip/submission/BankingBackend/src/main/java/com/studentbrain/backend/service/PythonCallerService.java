package com.studentbrain.backend.service;

import com.studentbrain.backend.dto.RequestsAI.CategorizeRequest;
import com.studentbrain.backend.dto.RequestsAI.Chat;
import com.studentbrain.backend.dto.RequestsAI.ChatMessage;
import com.studentbrain.backend.helper.TransactionExporter;
import com.studentbrain.backend.helper.UserExporter;
import org.apache.camel.ProducerTemplate;
import org.springframework.stereotype.Service;

@Service
public class PythonCallerService {

    private final ProducerTemplate producerTemplate;
    private final TransactionExporter transactionExporter;
    private final UserExporter userExporter;

    public PythonCallerService(ProducerTemplate producerTemplate,
                               TransactionExporter transactionExporter,
                               UserExporter userExporter) {
        this.producerTemplate = producerTemplate;
        this.transactionExporter = transactionExporter;
        this.userExporter = userExporter;
    }

    public Object sendToPython(CategorizeRequest request) {
        return producerTemplate.requestBody("direct:callPython", request);
    }

    public Object sendChatToPython(ChatMessage request) throws Exception {
        String transactionContext = transactionExporter.exportAsJson();
        String userContext = userExporter.exportAsJson();

        Chat chat = new Chat(request.reset(), request.message(), userContext, transactionContext);

        return producerTemplate.requestBody("direct:callChat", chat);
    }
}