package com.studentbrain.backend.dto;

public record UserGroupDto (String name){
}
