package com.studentbrain.backend.controller;

import com.studentbrain.backend.dto.RequestsAI.CategorizeRequest;
import com.studentbrain.backend.dto.RequestsAI.ChatMessage;
import com.studentbrain.backend.service.PythonCallerService;
import lombok.AllArgsConstructor;
import org.apache.camel.ProducerTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/python")
public class CamelController {

    private final ProducerTemplate producerTemplate;
    private final PythonCallerService pythonCallerService;

    // Konstruktorname muss identisch zum Klassennamen sein!
    public CamelController(ProducerTemplate producerTemplate, PythonCallerService pythonCallerService) {
        this.producerTemplate = producerTemplate;
        this.pythonCallerService = pythonCallerService;
    }

    @PostMapping("/categorize")
    public Object callPython(@RequestBody CategorizeRequest request) {
        // sendBodyAndReturn ruft direct:callPython auf
        return producerTemplate.requestBody("direct:callPython", request);
    }

    @PostMapping("/chat")
    public Object callChat(@RequestBody ChatMessage request) throws Exception {
        // sendBodyAndReturn ruft direct:callPython auf
        return pythonCallerService.sendChatToPython(request);
    }
}