package com.studentbrain.backend.dto;

public record ResponseSubAccountDto(String name, float currentAmount,float goalAmount, String description,float dayLefts) {

}
