package com.studentbrain.backend.controller;

import com.studentbrain.backend.dto.CreateGroupDto;
import com.studentbrain.backend.dto.UserGroupDto;
import com.studentbrain.backend.model.UserGroup;
import com.studentbrain.backend.service.UserGroupService;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.apache.catalina.User;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/group")
@AllArgsConstructor
public class UserGroupController {
    private UserGroupService userGroupService;

    @PatchMapping("/add")
    public ResponseEntity<UserGroup> addAccountToGroup(@RequestBody CreateGroupDto createGroupDto){

        UserGroup updatedGroup = userGroupService.addAccountToGroup(createGroupDto.groupId(), createGroupDto.accountId());
        return ResponseEntity.ok(updatedGroup);
    }

    @PostMapping("create")
    public ResponseEntity<UserGroup> createGroup(@RequestBody UserGroupDto userGroupDto) {
        UserGroup saved = userGroupService.createGroup(userGroupDto);
        return ResponseEntity.status(201).body(saved);
    }

}
