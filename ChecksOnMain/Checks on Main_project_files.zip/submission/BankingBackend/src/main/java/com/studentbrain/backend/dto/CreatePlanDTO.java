package com.studentbrain.backend.dto;

import com.studentbrain.backend.enums.Category;

public record CreatePlanDTO (
        Category category, long currentAmount, long limitValue, Long holderId
)
{}
