package com.studentbrain.backend.dto;

public record SubAccountResponseDto(String name, float currentAmount, float goalAmount) {
}
