package com.studentbrain.backend.dto;

public record InitTransactionDTO(
    String purpose,
    Double amount,
    Long accountId,
    Long receiverId
){}
