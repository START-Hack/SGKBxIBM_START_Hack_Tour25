package com.studentbrain.backend.dto;

public record RequestAccountDto(long accountId) {
}
