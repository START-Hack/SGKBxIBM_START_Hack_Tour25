package com.studentbrain.backend.service;

import com.studentbrain.backend.dto.UserGroupDto;
import com.studentbrain.backend.model.Account;
import com.studentbrain.backend.model.UserGroup;
import com.studentbrain.backend.repository.AccountRepository;
import com.studentbrain.backend.repository.UserGroupRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class UserGroupService {
    //attributes

    private UserGroupRepository userGroupRepository;
    private AccountRepository accountRepository;

    //methods
    public UserGroup createGroup(UserGroupDto userGroupDto) {
        UserGroup userGroup = new UserGroup();
        userGroup.setName(userGroupDto.name());
        return userGroupRepository.save(userGroup);
    }

    public UserGroup addAccountToGroup(Long groupId, Long accountId) {
        UserGroup group = userGroupRepository.findById(groupId)
                .orElseThrow(() -> new RuntimeException("Group not found"));

        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new RuntimeException("Account not found"));
        account.setUserGroup(group);
        accountRepository.save(account);
        return group;
    }

}
