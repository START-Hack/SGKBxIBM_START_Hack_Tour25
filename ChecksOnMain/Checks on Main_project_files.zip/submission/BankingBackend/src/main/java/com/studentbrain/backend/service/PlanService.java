package com.studentbrain.backend.service;

import com.studentbrain.backend.dto.CreatePlanDTO;
import com.studentbrain.backend.model.Account;
import com.studentbrain.backend.model.Plan;
import com.studentbrain.backend.repository.AccountRepository;
import com.studentbrain.backend.repository.PlanRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class PlanService {
    private final AccountRepository accountRepository;
    PlanRepository planRepository;

    public PlanService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    public void createPlan(CreatePlanDTO dto){
        Account holder = accountRepository.findById(dto.holderId())
                        .orElseThrow(() -> new EntityNotFoundException("Account not found" + dto.holderId()));
        Plan plan = new Plan(holder, dto.category(), dto.limitValue());
        planRepository.save(plan);
    }
    public void deletePlan(Long id){
        planRepository.deleteById(id);
    }
}
