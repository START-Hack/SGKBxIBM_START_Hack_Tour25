package com.studentbrain.backend.dto;

import java.time.LocalDate;

public record SubAccountDto(String name, float goalAmount, float claimOnSaldo,String description, LocalDate localDate) {
}
