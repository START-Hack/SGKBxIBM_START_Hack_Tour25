package com.studentbrain.backend.controller;

import com.studentbrain.backend.dto.CreateTransactionDTO;
import com.studentbrain.backend.dto.InitTransactionDTO;
import com.studentbrain.backend.service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor

public class TransactionController {

    private final TransactionService transactionService;

    @PostMapping("/init")
    public ResponseEntity<Void> initTransaction(@RequestBody InitTransactionDTO initTransactionDTO) {
        transactionService.initTransaction(initTransactionDTO);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
    @PostMapping("/create")
    public ResponseEntity<Void> createTransaction(@RequestBody CreateTransactionDTO createTransactionDTO) {
        transactionService.createTransaction(createTransactionDTO);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}
