package com.studentbrain.backend.dto;

public record PatchSubAccountRequest(long mainAccountId, long subAccountId, String value) {
}
