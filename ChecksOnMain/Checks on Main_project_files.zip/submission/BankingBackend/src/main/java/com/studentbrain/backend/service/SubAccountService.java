package com.studentbrain.backend.service;

import com.studentbrain.backend.dto.SubAccountDto;
import com.studentbrain.backend.model.SubAccount;
import com.studentbrain.backend.repository.SubAccountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class SubAccountService {

    public SubAccount createSubAccount(SubAccountDto subAccountDto) {
        SubAccount subAccount = new SubAccount();
        subAccount.setName(subAccountDto.name());
        subAccount.setGoalAmount(subAccountDto.goalAmount());
        subAccount.setClaimOnSaldo(subAccountDto.claimOnSaldo());
        return subAccount;
    }


}
