package com.studentbrain.backend.constant;

public class Constant {
    public static final int HUNDRED = 100;
}
