package com.studentbrain.backend.model;

import com.studentbrain.backend.enums.Category;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"holder_id", "category"}))
public class Plan {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "holder_id", nullable = false)
    private Account holder;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Category category;

    private long currentAmount;
    private long limitValue;
    @ElementCollection
    @CollectionTable(name = "plan_dates", joinColumns = @JoinColumn(name = "plan_id"))
    @Column(name = "date")
    private List<LocalDate> dates = new ArrayList<>();
    public Plan(Account holder, Category category, long limitValue){
        this.holder = holder;
        this.category = category;
        this.limitValue = limitValue;
        this.currentAmount = 0;
    }
}