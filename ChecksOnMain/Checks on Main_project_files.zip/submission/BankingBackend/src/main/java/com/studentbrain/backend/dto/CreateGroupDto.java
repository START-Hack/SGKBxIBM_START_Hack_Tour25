package com.studentbrain.backend.dto;

public record CreateGroupDto(Long groupId,Long accountId) {
}
