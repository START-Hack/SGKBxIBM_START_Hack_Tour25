package com.studentbrain.backend.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.studentbrain.backend.constant.Constant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDate;

import static java.time.temporal.ChronoUnit.DAYS;

@Setter
@Getter
@Entity
public class SubAccount {
    private static final Logger log = LogManager.getLogger(SubAccount.class);
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private float currentAmount = 0;
    private float goalAmount;
    private float claimOnSaldo;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate targetDate;
    private String description;

    @ManyToOne
    @JoinColumn(name = "master_account")
    @JsonIgnore
    private Account account;

    public float calculateDailyRecommendation() {
        if (targetDate == null) {
            return 0;
        }

        long daysLeft = DAYS.between(LocalDate.now(), this.targetDate);
        log.info("See the daysleft: " + daysLeft);
        float remaining = goalAmount - currentAmount;

        if (remaining <= 0) return 0; // Ziel erreicht
        if (daysLeft <= 0) return remaining; // überfällig → alles sofort

        return remaining / daysLeft;
    }

    public long getDayLefts() {
        return DAYS.between(LocalDate.now(), this.targetDate);
    }

    /**
     * saving rate will be calculated based on the main account,
     * so that we can  credit the subaccount and debit the main account
     *
     * @return
     */
    public float calculateSavingRate() {
        return this.account.getSaldo() * (claimOnSaldo / Constant.HUNDRED);
    }

    public float calculateSavingRateWithProvidedValue(float value) {
        return value * (claimOnSaldo / Constant.HUNDRED);
    }
}
