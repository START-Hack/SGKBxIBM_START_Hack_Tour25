package com.studentbrain.backend.repository;

import com.studentbrain.backend.model.SubAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubAccountRepository extends JpaRepository<SubAccount, Long> {
    List<SubAccount> findByAccount_Id(Long id);
}
