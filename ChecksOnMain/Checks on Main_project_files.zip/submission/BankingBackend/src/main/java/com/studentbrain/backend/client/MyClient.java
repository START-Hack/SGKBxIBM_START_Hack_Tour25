package com.studentbrain.backend.client;


import com.studentbrain.backend.dto.RequestsAI.CategorizeRequest;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@Service
public class MyClient {
    private final RestClient rest;

    public MyClient(RestClient.Builder builder) {
        this.rest = builder.baseUrl("http://localhost:8000").build();
    }

    public String getCategory(CategorizeRequest cr) {
        // IMPORTANT: pass the OBJECT, not a String
        return rest.post()
                .uri("/api/classify")         // match FastAPI route exactly (slash vs no-slash)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(cr)                     // Jackson kicks in here
                .retrieve()
                .body(String.class);
    }
}