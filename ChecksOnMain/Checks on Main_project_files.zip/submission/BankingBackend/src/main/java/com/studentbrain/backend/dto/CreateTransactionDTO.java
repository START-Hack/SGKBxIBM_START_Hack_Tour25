package com.studentbrain.backend.dto;

import com.studentbrain.backend.enums.Category;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

import java.time.LocalDateTime;

public record CreateTransactionDTO(
        Double amount,
        Long accountId,
        /**
         * val 1= receiving money
         * val 2= outgoing money
         */
        int direction,
        String purpose,
        String counterParty
){}
