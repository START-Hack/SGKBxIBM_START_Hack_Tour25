package com.studentbrain.backend.dto.RequestsAI;

public record CategorizeAnswer() {
}
