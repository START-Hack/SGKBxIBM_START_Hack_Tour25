package com.studentbrain.backend.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.studentbrain.backend.dto.*;
import com.studentbrain.backend.service.AccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/accounts")
@RequiredArgsConstructor

public class AccountController {

    private final AccountService accountService;


    @PostMapping("/create")
    public ResponseEntity<CreateAccountDto> createAccount(@RequestBody CreateAccountDto createAccountDto) {
        CreateAccountDto saved = accountService.createAccount(createAccountDto);
        return new ResponseEntity<CreateAccountDto>(saved, HttpStatus.CREATED);
    }

    @PostMapping("/create/subaccount")
    public ResponseEntity<CreateSubAccountDto> createSubAccount(@RequestBody CreateSubAccountDto createSubAccountDto) {
        accountService.createSubAccount(createSubAccountDto.accountId(), createSubAccountDto.subAccountDto());
        return new ResponseEntity(createSubAccountDto, HttpStatus.CREATED);
    }

    @PostMapping("/splitFunds")
    public ResponseEntity<String> delegateMoneyToSubAccount(@RequestBody RequestAccountDto requestAccountDto) {
        accountService.delegateMoney(requestAccountDto.accountId());
        return new ResponseEntity<String>("Amount has been successful transferred  into your sub accounts", HttpStatus.ACCEPTED);
    }

    @GetMapping("/request")
    public ResponseEntity<CreateAccountDto> getAccountState(@RequestBody RequestAccountDto requestAccountDto) {
        return new ResponseEntity<>(accountService.getAccountState(requestAccountDto.accountId()), HttpStatus.OK);
    }

    @PatchMapping("/send")
    public ResponseEntity<SubAccountResponseDto> sendMoneyToSubAccount(@RequestBody PatchSubAccountRequest patchSubAccountRequest) {
        return new ResponseEntity<SubAccountResponseDto>(accountService.increaseSubAccount(patchSubAccountRequest.mainAccountId(), patchSubAccountRequest.subAccountId(), Long.parseLong(patchSubAccountRequest.value())), HttpStatus.OK);
    }

    @GetMapping("/suggestion")
    public ResponseEntity<Float> requestSavingSuggestion(@RequestBody RequestSubAccountRateDto requestSubAccountRateDto) {
        ObjectMapper mapper = new ObjectMapper();
        return new ResponseEntity<Float>(accountService.requestSavingSuggestion(requestSubAccountRateDto), HttpStatus.OK);
    }

    @GetMapping("/request/subaccount")
    public ResponseEntity<ResponseSubAccountDto> getSubAccount(@RequestBody RequestSubAccountRateDto requestSubAccountRateDto) {
        return new ResponseEntity<>(accountService.getSubAccount(requestSubAccountRateDto), HttpStatus.OK);
    }

    @GetMapping("request/subaccounts")
    public ResponseEntity<List<SubAccountName>> getSubAccounts(@RequestBody Long accountId) {
        return new ResponseEntity<>(accountService.getAccounts(accountId), HttpStatus.OK);
    }
}