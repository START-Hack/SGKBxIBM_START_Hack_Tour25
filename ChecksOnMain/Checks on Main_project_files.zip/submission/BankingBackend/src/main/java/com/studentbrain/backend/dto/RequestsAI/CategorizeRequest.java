package com.studentbrain.backend.dto.RequestsAI;

public record CategorizeRequest(
        String direction, String amount, String currency, String purpose
) {}
