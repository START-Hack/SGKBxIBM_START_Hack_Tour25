package com.studentbrain.backend.route;

import com.studentbrain.backend.dto.RequestsAI.CategorizeRequest;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

@Component
public class PythonRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        from("direct:callPython")
                .routeId("pythonRoute")
                .marshal().json(JsonLibrary.Jackson, CategorizeRequest.class)
                .to("http://localhost:8000/api/classify")
                .log("Response from Python: ${body}");

        from("direct:callChat")
                .routeId("chatRoute")
                .marshal().json()
                .to("http://localhost:8000/api/chat")
                .log("Response from Python: ${body}");
    }

}
