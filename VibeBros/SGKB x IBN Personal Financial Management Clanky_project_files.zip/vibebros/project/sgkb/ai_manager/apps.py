from django.apps import AppConfig


class AiManagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ai_manager'
